import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
from math import *
from random import *

sec = Section(Vec2(0, 0), Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))

# 测试面布尔, 两个面相减
# secOrig = Section(Vec2(10,0),Vec2(0,20),Vec2(-10,0),Vec2(0,-20))
# secClip = roty(pi/2)*Section(GeVec3d(0,-20,10),GeVec3d(0,20,10),GeVec3d(0,20,-10),GeVec3d(0,-20,-10))
secOrig = roty(pi/2)*Section(Vec2(10, 0), Vec2(0, 20),
                             Vec2(-10, 0), Vec2(0, -20))
secClip = Section(GeVec3d(0, -20, 10), GeVec3d(0, 20, 10),
                  GeVec3d(0, 20, -10), GeVec3d(0, -20, -10))
secCut = secClip - secOrig

# create_geometry(secOrig)
# create_geometry(secClip)
# create_geometry(secCut)

# create_geometry(trans(0,500)*secOrig)
# create_geometry(secClip)
# create_geometry(secOrig-secClip)
# create_geometry(secOrig+secClip)
# create_geometry(Sphere()-Cube())

#　圆形截面布尔
# 圆与圆
secarc = Section(scale(10)*Arc())
secarc2 = trans(5, 0)*secarc
sec_add = secarc + secarc2
sec_sub = secarc - secarc2
# create_geometry(secarc2)
# create_geometry(secarc)
# create_geometry(sec_add)

# 圆与矩形
sec_rect = Section(Vec2(-10, -10), Vec2(10, -10), Vec2(10, 10), Vec2(-10, 10))
sec_add = sec_rect + secarc
sec_sub = -secarc + sec_rect
# create_geometry(secarc)
# create_geometry(sec_rect)
# create_geometry(sec_sub)

# 体布尔嵌套
G1 = scale(100)*Cube()
G2 = trans(0, -80, 0)*G1
G3 = trans(80, 0, 0)*G1
G4 = trans(80, -80, 0)*G1
G5 = trans(160, 0, 0)*G1

Z = Intersect(G1+(G3-G4), G5)
Z = G1+(G3-G4)
Z = G1-Intersect(G1+G2, G3+G4)+G5
g1 = Sphere()
# create_geometry(G1-intersection(G1,G2))
# create_geometry(translate(5,0)*(translate(4,0)*G3-translate(3,0)*Intersect(translate(1,0)*G1,translate(2,0)*G2)))
# create_geometry(G3-intersection(G1,G2))
# create_geometry(G3-intersection(G1,G2))
# create_geometry(G3-intersection(G1,G2))
# create_geometry(intersection(G1,G2)+G3)
# create_geometry(intersection(G1,G2)+G3)
# create_geometry(intersection(intersection(G3,G1),G2))


# ---------------------------------------------------
# 布尔交 intersect测试
g1 = Sphere()
g2 = Cube()
g3 = trans(-1, -1, 0)*Box()
# create_geometry(Intersect(g1-g2,g3))
# create_geometry(scale(100)*Intersect(g1,g2))
# create_geometry(scale(100)*(g2))


A = Section(Vec2(1, 0), Vec2(1, 2), Vec2(-1, 2), Vec2(-1, 0))
B = Section(Arc())
Z = (A+B)
# create_geometry(scale(100)*Sweep(Z,Line(Vec3(0,0,0),Vec3(0,0,1))))
sec1 = Section(Vec2(0, 0), Vec2(1, 0), Vec2(1, 1), Vec2(0, 1))
sec2 = Section(Arc(pi))
sec3 = trans(0.5, 0.5, 0)*sec1
sec4 = trans(1, 1, 0)*sec1
create_geometry(scale(100)*rotz(pi/4) *
                Intersect(rotz(pi/6)*sec1, rotz(pi/6)*sec2))

msec = rotz(pi/6)*sec1+sec2
secFu = rotz(pi/6)*sec1+sec2
sec = scale(100)*rotz(pi/2)*msec
sec = scale(100)*rotz(pi/2)*(rotz(pi/6)*Intersect(sec1, sec2))
sec = scale(100)*rotz(pi/2)*Intersect(msec)
sw1 = Sweep(secFu, Line(Vec3(0, 0, 0), Vec3(0, 0, 10)))
create_geometry(sw1)
sw2 = Sweep(Intersect(sec1, sec2), Line(
    Vec3(0, 0, 0), Vec3(0, 0, 10)))
create_geometry(trans(10, 0)*sw2)

# 布尔嵌套
A = Section(Vec2(1, 0), Vec2(1, 2), Vec2(-1, 2), Vec2(-1, 0))
# B=translate(0,-1)*A
# C=translate(1,-1)*A
# D=translate(1,-2)*A
B = Section(Arc())
C = trans(1, 0)*B
D = trans(1, -2)*A
Z = (A+B)
# Z=(C+B+A)
# Z=(A+B)+C
# Z=(C-D)+(A+B)
# Z=(A+B)-(C+D)
# Z=Intersect((A+B),C)

# Z=(A+B)+(C+D)+(A+B+C)
# Z=A+B+(C+D)+(A+B+C)
# Z=(A+B)+(C+D)-(E+F+G)
# create_geometry(scale(100)*(A+B+C))
# create_geometry(scale(100)*Z)
# create_geometry(scale(100)*Sweep(Z,Line(Vec3(0,0,0),Vec3(0,0,1))))
# create_geometry(scale(100)*Loft(Z,translate(0,0,1)*Z))

# create_geometry(Loft(secCut,translate(100,0,0)*secCut))
# create_geometry(Loft(secOrig,translate(100,0,0)*secOrig))
# create_geometry(Loft(secClip,translate(100,0,0)*secClip))
# create_geometry(inverse_std(roty(pi/2))*secOrig)
# create_geometry(inverse_std(roty(pi/2))*secClip)
a = cross(Vec3(1, 0, 0), Vec3(1, 0, 0))

ls0 = [Vec3(0, 0, 0), Vec3(1, 0, 0), Vec3(
    2, 0, 0), Vec3(3, 1, 0), Vec3(4, 2, 0)]
ls1 = remove_collinear_point(ls0)
# create_geometry(Line(ls1))


secList = []
num = 20
for i in range(1, num):  # 两圆相减
    arccut = Section(Arc())-translate(2-2*i/num, 0, 0)*Section(Arc())
    secList.append(translate(0, 0, 2*i/num)*arccut)

# create_geometry(scale(100)*Loft(secList)) #圆section布尔，失败(底面非圆，圆缺)


# --------------------------------------------------
# 体布尔-测试
A = Sphere()
B = Box()
C = Extrusion()
D = Cone()
E = translate(3, 0, 0)*A
F = translate(3, 0, 0)*D
G = translate(3, 0, 0)*B

# E=(A+B)+(C+D)+(A+B+C)
# E=A+B+(C+D)+(A+B+C)
Z = (A+B)+(C+D)-(E+F+G)
# create_geometry(scale(100)*Z)
# create_geometry(Conus2(100,100))

# 球球布尔
sphere1 = scale(10)*Sphere()
sphere2 = trans(11, 0) * sphere1
sph_add = sphere1 + sphere2
sph_sub = sphere1 - sphere2

create_geometry(sphere2)
create_geometry(sphere1)
create_geometry(trans(50, 0)*sph_add)
create_geometry(trans(-50, 0)*sph_sub)

cube1 = scale(10)*Cube()
cube2 = trans(-10, 0)*scale(10)*Cube()
cs_add = cube1 + cube2 + sph_add
cs_sub = cube1 + cube2 - sphere1 - sphere2
create_geometry(trans(50, 50)*cs_add)
create_geometry(trans(50, -50)*cs_sub)
