import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *


# ----------------------------------------------------------------------------
# ARC
# 3点画圆
text1 = Text('3点画圆').color(1, 1, 1, 1)
text1.size = 10
create_geometry(text1)
arc_1 = arc_of_three_points(Vec2(100, 0), Vec3(130, 130, 50), Vec2(0, 100))
create_geometry(arc_1.color(0, 0.5, 0.5, 1))

# 圆心-起点-终点
text2 = Text('圆心-起点-终点').color(1, 1, 1, 1)
text2.size = 10
create_geometry(trans(300, 0)*text2)
arc_2 = arc_of_center_points(Vec2(0, 0), Vec2(100, 0), Vec2(-100, 0))
create_geometry(trans(400, 0)*arc_2.color(0, 0.5, 0.5, 1))

# 起点-终点-半径-定位平面
text3 = Text('起点-终点-半径-定位平面').color(1, 1, 1, 1)
text3.size = 10
create_geometry(trans(-500, 0)*text3)
arc_3 = arc_of_radius_points_3D(Vec3(0, 0, 0), Vec3(
    100, 0, 50), 60.0, GeTransform([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]]))
create_geometry(trans(-400, 0)*arc_3.color(0, 0.5, 0.5, 1))

# 起点-终点-半径
text4 = Text('起点-终点-半径').color(1, 1, 1, 1)
text4.size = 10
create_geometry(trans(0, 400)*text4)
arc_4 = arc_of_radius_points_2D(Vec2(0, 0), Vec2(100, 50), 80.0)
create_geometry(trans(0, 400)*arc_4.color(0, 0.5, 0.5, 1))

# 三点组成线段，倒角圆弧
text5 = Text('三点组成线段，倒角圆弧').color(1, 1, 1, 1)
text5.size = 10
create_geometry(trans(0, -400)*text5)
arc_5 = arc_of_segments_bevel(
    [Vec2(0, -100), Vec2(130, 20), Vec2(90, 110)], 40.0)
create_geometry(trans(0, -400)*arc_5.color(0, 0.5, 0.5, 1))

# 位矢-半径-角度
text6 = Text('位矢-半径-角度').color(1, 1, 1, 1)
text6.size = 10
create_geometry(trans(-500, 400)*text6)
arc_6 = arc_of_tangent_radius_2D(PosVec(Vec2(0, 0), Vec2(0, 1)), 100.0, 2/3*pi)
create_geometry(trans(-400, 400)*arc_6.color(0, 0.5, 0.5, 1))

# 用5个点生成椭圆
text7 = Text('用5个点生成椭圆').color(1, 1, 1, 1)
text7.size = 10
create_geometry(trans(400, 400)*text7)
arc_7 = arc_of_five_points([Vec2(100, 10), Vec2(80, 45), Vec2(
    0, 50), Vec2(-60, 40), Vec2(-100, 10)], False)
create_geometry(trans(400, 400)*arc_7.color(0, 0.5, 0.5, 1))

# 与两个圆外切的圆弧
text8 = Text('与两个圆外切的圆弧').color(1, 1, 1, 1)
text8.size = 10
create_geometry(trans(400, -400)*text8)
arc_8 = arc_of_two_excircles(
    scale(50)*Arc(), trans(70, 90)*scale(100)*Arc(), 35, True)
create_geometry(trans(400, -400)*arc_8.color(0, 0.5, 0.5, 1))

# 设定长轴短轴、起始角终止角的标准椭圆
text9 = Text('设定长轴短轴、起始角终止角的标准椭圆').color(1, 1, 1, 1)
text9.size = 10
create_geometry(trans(-500, -400)*text9)
arc_9 = arc_of_oval_angle(100, 50, 0, pi, True, True)
create_geometry(trans(-400, -400)*arc_9.color(0, 0.5, 0.5, 1))

# 圆弧反转
text10 = Text('圆弧反转').color(1, 1, 1, 1)
text10.size = 10
create_geometry(trans(1000, 0)*text10)
arc_10 = arc_reverse(scale(100)*Arc(3/2*pi), True, False)
create_geometry(trans(1000, 0)*arc_10.color(0, 0.5, 0.5, 1))

# 通过线段打断Arc(only circle)
text11 = Text('通过线段打断Arc').color(1, 1, 1, 1)
text11.size = 10
create_geometry(trans(-1000, 0)*text11)
arc_11 = arc_of_segment_interrupt(
    Segment(Vec2(0, -300), Vec2(20, 300)), scale(80)*Arc(3/2*pi), True)
create_geometry(trans(-1000, 0)*arc_11.color(0, 0.5, 0.5, 1))

# other arc
points = [Vec3(), Vec3(100, 100), Vec3(150, -100), ]
show_points_line(points)
arc = arc_of_segments_bevel(points, 50)
create_geometry(arc)
show_arc_direction(arc)

arc = arc_of_three_points(Vec2(100, 0), Vec3(130, 130, 50), Vec2(0, 100))
# show_points_line(trans(arc.pointStart)*[g_axisO, 100*arc.vectorTangentS])
# show_points_line(trans(arc.pointEnd)*[g_axisO, 100*arc.vectorTangentE])
# show_arc_direction(arc3)

points = [Vec2(100, 10), Vec2(80, 45), Vec2(
    00, 50), Vec2(-60, 40), Vec2(-100, 10), ]
show_points_line(points)
arc = arc_of_five_points(points, False)
create_geometry(arc)
# 创建椭圆
# create_geometry(arc)
# show_points_line([Vec3(), scale(a)*Vec3(cos(deg2rad(120)), sin(deg2rad(120)))])
create_geometry(arc)
# a, b, thetaL, thetaR = get_arc_rotate_angle_2D(arc)
# angleL = rad2deg(thetaL)
# angleR = rad2deg(thetaR)
# arcE = arc_of_oval_angle(a, b, 0, 2*pi, True, True)
# create_geometry(rotz(thetaL)*arcE)

# 计算周长
len2 = get_perimeter_of_arc(arc)
# len3 = get_perimeter_of_curve(arc)
points = get_discrete_points_from_arc(arc, 100)
# show_points_line(points)
len4 = get_perimeter_of_polygon(points)
# create_geometry(scale(a)*Arc())
# theta = arc_alpha2theta(deg2rad(30), a, b)
# print(rad2deg(theta))
# print(rad2deg(arc.scope))
# show_points_line([Vec3(), scale(a)*Vec3(cos(deg2rad(30)), sin(deg2rad(30)))])
# show_points_line([Vec3(), scale(a)*Vec3(cos(theta), sin(theta))])

# ps = get_discrete_points_from_ellipse(rotz(pi/6)*arc, 11)
# show_points_line(ps)
arc1 = rotz(-pi/6)*scale(200, 100)*rotz(pi/6)*Arc()
# arcR = inverse_std(get_orthogonal_matrix(arc1.transformation))*arc1
# create_geometry(arcR)
res = get_arc_rotate_angle_2D(arc1)
# angle = get_angle_of_two_vectors(g_axisX, arc1.pointStart)
angle = get_angle_of_two_vectors(arc1.pointStart, Vec2(1, 1))
ab = get_arc_axis_and_angle_2D(arc1)
coe = get_coefficients_from_arc(arc1)
# show_points_line([Vec3(), 200*Vec3(cos(coe2[2]), sin(coe2[2]))])
# show_coordinate_system()
arc = scale(100)*Arc(Vec3(0, 0, -1), Vec3(0, 1, 0), Vec3(1, 0, 1))
pStart = arc.pointStart
pEnd = arc.pointEnd
print_result(is_coincident(pStart, Vec3(0, 0, -100)))
print_result(is_coincident(pEnd, Vec3(100, 0, 100)))

# create_geometry(arc)
# create_geometry(scale(100)*Line(Vec3(0,-1,0),arc,Vec3(0,-1,1))) #三点弧连线正确
d_arc = get_discrete_points_from_arc(arc, 10, True)
# create_geometry(Line(d_arc))

# ------------------------------------------------------------------------------------------
# PATTERN
# 十点五角星(外接圆半径)
five = five_points_star(100, False)
sec_1 = Section(five)
create_geometry(sec_1.color(0, 0.5, 0.5, 1))

# XoY平面正多边形
polygon = regular_polygon(5, 50)
sec_2 = Section(polygon)
create_geometry(sec_2.color(0, 0.5, 0.5, 1))

# 中心对称圆角矩形(XoY)
rectangle = rectangle_central_symmetry(50, 100, 5)
sec_3 = Section(rectangle)
create_geometry(sec_3.color(0, 0.5, 0.5, 1))

# 对角线圆角矩形(XoY)
diagonal = rectangle_diagonal(Vec2(0, 0), Vec2(100, 50), 5)
create_geometry(diagonal.color(0, 0.5, 0.5, 1))


# ------------------------------------------------------------------------------------------
# BODY
# 莫比乌斯环(圆环)
sec_1 = Section(Vec2(0, 0), Vec2(5, 0), Vec2(10, 5), Vec2(0, 5))
mubiu = sweep_mubiu_arc(sec_1, 100.0, 5)
create_geometry(mubiu.color(0, 0.5, 0.5, 1))

# 正四面体 pyramid shape
pyramid_shape = std_tetrahedron(100)
create_geometry(trans(300, 0)*pyramid_shape.color(0, 0.5, 0.5, 1))

# 圆环
yuanhuan = std_ring(100, 50, 2*pi)
create_geometry(trans(-300, 0)*yuanhuan.color(0, 0.5, 0.5, 1))

# （标准）圆锥
yuanzhui_1 = conus_diameter_height(100, 100)
create_geometry(trans(0, 300)*yuanzhui_1.color(0, 0.5, 0.5, 1))

# （顶点）圆锥
yuanzhui_2 = conus_underside_vertex(scale(100)*Arc(), Vec3(0, 0, 100))
create_geometry(trans(0, -300)*yuanzhui_2.color(0, 0.5, 0.5, 1))

# ------------------------------------------------------------------------------------------
# SHOW
# 显示线段所在直线（延长线）
line_1 = Segment(Vec3(-10, 20, 5), Vec3(50, 80, 40))
# line_a = show_extend_line(line_1)
# show_line_extend
p = Vec3(20, 5, 40)
# show_2 = show_line_extend(p, isX=True)

# 显示坐标系及XoY平面
mat_1 = get_matrix_from_two_vectors(Vec3(3, 1, 0), Vec3(30, 20, 0))
show_1 = show_coordinate_plane(mat_1, sca=1)

# show_section_box_surround_2D
sec_2 = Section(Vec2(0, 0), Vec2(5, 0), Vec2(10, 5), Vec2(0, 5))
# show_3 = show_section_box_surround_2D(sec_2) #将显示延长线

# 显示坐标系
mat_2 = get_matrix_from_two_vectors(Vec3(3, 1, 0), Vec3(30, 20, 0))
show_4 = show_coordinate_system(mat_2, scal=1, kr=1)

# 显示点线
list_1 = [Vec3(20, 10), Vec3(50, -20), Vec3(40, 30), Vec3(80, 0)]
show_5 = show_points_line(list_1, 0, True, True)

# 标高参考平面
text0 = '标高参考平面'
show_6 = show_standard_height_plane(50.0, text0, sca=1)
