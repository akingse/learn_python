import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用

'''
功能测试 4个Arc
矩阵测试 3个Arc
圆弧画法 4种

'''
clear_entity()
# ----------------------------------------------------------------------------
# 功能测试
text1 = Text('Arc()').color(1, 1, 1, 1)
text1.size = 20
create_geometry(text1)
arc = scale(100)*Arc()
create_geometry(arc.color(0, 0.5, 0.5, 1))

text2 = Text('Arc(s)')
text2.size = 20
create_geometry(trans(0, 150, 0)*text2)
create_geometry(trans(0, 300, 0)*scale(100)*Arc(1.5*pi))

text2 = Text('Arc(3)')
text2.size = 20
create_geometry(trans(200, 0, 0)*text2)
create_geometry(scale(100)*Arc(Vec2(2, 0), Vec2(3, 1), Vec2(4, 0)))

text2 = Text('Arc(5)')
text2.size = 20
create_geometry(trans(200, 150, 0)*text2)
create_geometry(scale(100)*Ellipse(Vec3(3, 3, 0),
                                   Vec3(1, 0, 0), Vec3(0, 1, 0), 0, 1.5*pi))


# ----------------------------------------------------------------------------
# 矩阵测试
# translate()
# scale()
# compound matrix
text3 = Text('trans-rot')
text3.size = 20
create_geometry(trans(600, 600, 0)*text3)
arc1 = trans(800, 0, 0)*scale(100)*Arc(1.5*pi)
# rotate 旋转平移矩阵
T = arbitrary_rotate(Vec3(0, 0, 0), Vec3(0, 0, 1), pi/4)
create_geometry(T*arc1.color(0, 0.5, 0.5, 1))

# shear 错切矩阵 （暂不支持）
text4 = Text('shear arc')
text4.size = 20
create_geometry(trans(1000, 0, 0)*text4)
T = trans(1000, 0, 0)*sheary(x=1, z=1)
create_geometry(T*arc)

# reflect 反射矩阵
text5 = Text('reflect arc')
text5.size = 20
create_geometry(trans(-1000, 0, 0)*text5)
# arc=scale(100)*arc(Vec3(2,2,2))
T = mirror(g_matrixE, 'XoZ')*mirror()
create_geometry(T*arc1.color(0, 0.5, 0.5, 1))

# while True:
#     sys.exit(0)
# -------------------------------------------------------------
