import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用

'''
# 使用三维文字测试矩阵
# 两类矩阵 # 刚性矩阵（rotate arbitrary_rotate rot rotx roty rotz translate）和线性矩阵（scale shear reflect）
'''
# ----------------------------------------------------------------------------


# 函数
def dimen3(string):
    line = Line(Vec3(0, 0, 0), Vec3(0, 0, 1))
    text = Text("→"+string)
    text.size = 10
    return Sweep(text, line)


# 刚性变换
create_geometry(dimen3(""))
T = rotate(pi/2)  # rotate(Vec3(0,0,1),pi/2)
create_geometry(T*dimen3('rotate'))
T = rotate(Vec3(0, 1, 0), pi/2)
create_geometry(T*dimen3("roty"))
T = arbitrary_rotate(Vec3(0.5, 3, 1), Vec3(0, 0, 1), pi/2)
create_geometry(T*dimen3("arbi"))
# T=rot('z',-pi/2)
create_geometry(T*dimen3("rot()"))
T = trans(-0.8, -3.6, 0)
create_geometry(T*dimen3("trans"))

# 线性变换
T = trans(2, 2, 0)*scale(2)
create_geometry(T*dimen3("s1"))
T = trans(3, 3**2, 0)*scale(3, 3)
create_geometry(T*dimen3("s2"))
T = trans(4, 4**2, 0)*scale(4, 4, 4)
create_geometry(T*dimen3("s3"))

T = trans(0, -10, 0)*shearx(y=1, z=1)
create_geometry(T*dimen3("shearx"))
T = trans(0, -20, 0)*sheary(x=1, z=1)
create_geometry(T*dimen3("sheary"))
T = trans(0, -30, 0)*shearz(x=1, y=1)
create_geometry(T*dimen3("shearz"))

T = mirror()
create_geometry(T*dimen3("mirror-y"))
T = mirror(g_matrixE, 'yoz')*trans(0, 10, 0)
create_geometry(T*dimen3("mirror-yz"))

# while True:
#     sys.exit(0)
