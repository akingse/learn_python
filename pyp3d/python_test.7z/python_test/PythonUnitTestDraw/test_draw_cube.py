import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用

'''
测试Cube及矩阵
5个cube
'''

# ----------------------------------------------------------------------------
# 功能测试
text1 = Text('a cube').color(1, 1, 1, 1)
text1.size = 20
create_geometry(trans(0, -50, 0)*text1)
text2 = Text('color cube')
text2.size = 20
create_geometry(trans(0, 250, 0)*text2)

cube = scale(100)*Cube()
create_geometry(cube)
create_geometry(trans(0, 300, 0)*cube.color(0, 0.5, 0.5, 1))
cube.color(0.5, 0.5, 0.5, 1)

# ----------------------------------------------------------------------------
# 矩阵测试
# translate()
# scale()
# compound matrix
text3 = Text('trans cube')
text3.size = 20
create_geometry(trans(300, 300, 0)*text3)
cube1 = trans(500, 0, 0)*scale(100)*Cube()
# rotate 旋转平移矩阵
T = arbitrary_rotate(Vec3(0, 0, 0), Vec3(0, 0, 1), pi/4)
create_geometry(T*cube1)

# shear 错切矩阵
text4 = Text('shear cube')
text4.size = 20
create_geometry(trans(300, -50, 0)*text4)
T = trans(300, 0, 0)*shearx(y=1, z=1)
create_geometry(T*cube)

# reflect 反射矩阵
text5 = Text('reflect cube')
text5.size = 20
create_geometry(trans(-100, -150, 0)*text5)
T = mirror(g_matrixE, 'XoZ')*mirror()
create_geometry(T*cube)
