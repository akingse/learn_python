import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

# 增加重合点提示

points = [Vec3(0, 0, 0), Vec3(600, -200, 0),
          Vec3(-300, -600, 0), Vec3(-300, -600, 0), Vec3(0, 0, 0)]
# show_points_line(points, 10)

# 圆弧方向可视化
arc = scale(100)*Arc(pi)
arc = scale(150, 100)*Arc(pi)
# show_arc_direction(arc)


# 显示样条线
sp = SplineCurve([Vec3(), Vec3(200, 300), Vec3(
    300, 0), Vec3(500, -500), Vec3(800, 0)])
# show_spline_curve(sp)


# 显示线组
# show_points_curve_line(Line(rotz(pi/2)*scale(300)*Arc(pi), Vec3(0, 0), sp))


show_coordinate_system()
