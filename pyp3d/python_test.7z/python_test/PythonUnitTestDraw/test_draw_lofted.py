import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用

# 两截面，引导线，原生写法
secBot = Section(Vec3(-500, -500, 0), Vec3(500, -500, 0),
                 Vec3(500, 500, 0), Vec3(-500, 500, 0))
secTop = transz(1200)*scale(0.6)*secBot

guideLine = [[Segment(Vec3(-500, -500, 0), Vec3(-300, -300, 1200)),
              Segment(Vec3(500, -500, 0), Vec3(300, -300, 1200)),
              Segment(Vec3(500, 500, 0), Vec3(300, 300, 1200)),
              Segment(Vec3(-500, 500, 0), Vec3(-300, 300, 1200))]]
lofted = Lofted(secBot, secTop, guideLine)
create_geometry(transx(-2000)*lofted.colorBlue())


# 展示轮廓线（二选一）
lofted.showTest = True
create_geometry(lofted)

# 单层引导线
guideLine = [Line(Vec3(-500, -500, 0), Vec3(-300, -300, 1200)),
             Line(Vec3(500, -500, 0), Vec3(300, -300, 1200)),
             Line(Vec3(500, 500, 0), Vec3(300, 300, 1200)),
             Line(Vec3(-500, 500, 0), Vec3(-300, 300, 1200))]  # Segment Line均可
lofted = Lofted(secBot, secTop, guideLine)
create_geometry(transy(2000)*lofted)

# 自动引导线
lofted = Lofted(secBot, secTop)
create_geometry(transy(4000)*lofted)

# 多段引导线
guideLine = [Line(Vec3(-500, -500, 0), Vec3(-500, -500, 500), Vec3(-300, -300, 1200)),
             Line(Vec3(500, -500, 0), Vec3(500, -500, 500),
                  Vec3(300, -300, 1200)),
             Line(Vec3(500, 500, 0), Vec3(500, 500, 500), Vec3(300, 300, 1200)),
             Line(Vec3(-500, 500, 0), Vec3(-500, 500, 500), Vec3(-300, 300, 1200))]
lofted = Lofted(secBot, secTop, guideLine)
create_geometry(transy(-2000)*lofted)

# 单圆截面暂不支持
# secBot = Section(scale(100)*Arc())
# secTop = transz(100)*secBot
# guideLine = [Segment(Vec3(100, 0, 0), Vec3(100, 0, 100))]
# lofted = Lofted(secBot, secTop, guideLine)
# lofted.showTest = True
# create_geometry(lofted)

# 圆弧截面，自动路径
secBot = transz(-300)*Section(scale(100)*Arc(pi/2), rotz(pi/2)*scale(100)*Arc(pi/2),
                              rotz(pi)*scale(100)*Arc(pi/2), rotz(3*pi/2)*scale(100)*Arc(pi/2))
secTop = transz(300)*Section(scale(100)*Arc(pi/2), rotz(pi/2)*scale(100)*Arc(pi/2),
                             rotz(pi)*scale(100)*Arc(pi/2), rotz(3*pi/2)*scale(100)*Arc(pi/2))

line = trans(100, 0)*Line(Vec3(0, 0, -300),
                          Arc(Vec3(0, 0, -100), Vec3(100, 0, 0), Vec3(0, 0, 100),), Vec3(0, 0, 300))
guideLine = [line, rotz(pi/2)*line, rotz(pi)*line, rotz(3*pi/2)*line]  # 一维列表
lofted = Lofted(secBot, secTop)
create_geometry(trans(1000, 0)*lofted)

# 圆弧截面，多段路径
lofted = Lofted(secBot, secTop, guideLine)
create_geometry(trans(1000, 1000)*lofted)


# -------------------------------------------------------------------------------------
#   fusion
# -------------------------------------------------------------------------------------
# 带洞布尔截面
secBot = Section(scale(200, 100)*Arc(pi), rotz(pi)*scale(200, 100)*Arc(pi)) - scale(0.5)*Section(scale(200, 100)*Arc(pi),
                                                                                                 rotz(pi)*scale(200, 100)*Arc(pi))
secTop = transz(300)*(Section(scale(100)*Arc(pi), rotz(pi)*scale(100)*Arc(pi)) - scale(0.5)*Section(scale(100)*Arc(pi),
                                                                                                    rotz(pi)*scale(100)*Arc(pi)))
guideLine = [[Segment(Vec3(200, 0), Vec3(100, 0, 300)), Segment(Vec3(-200, 0), Vec3(-100, 0, 300)), ],
             scale(0.5, 0.5)*[Segment(Vec3(200, 0), Vec3(100, 0, 300)), Segment(Vec3(-200, 0), Vec3(-100, 0, 300)), ]]

lofted = Lofted(secBot, secTop, guideLine)
create_geometry(trans(1000, 2000)*lofted)

# 带洞布尔截面，自动路径
lofted = Lofted(secBot, secTop)
create_geometry(trans(1000, 3000)*lofted)


# # 带洞布尔截面2
secBot = Section(Vec3(200, 0), Vec3(0, 100), Vec3(-200, 0), Vec3(0, -100)) - \
    scale(0.5)*Section(Vec3(200, 0), Vec3(0, 100),
                       Vec3(-200, 0), Vec3(0, -100))
secTop = transz(300)*(Section(Vec3(100, 0), Vec3(0, 100), Vec3(-100, 0), Vec3(0, -100)) -
                      scale(0.5)*Section(Vec3(100, 0), Vec3(0, 100), Vec3(-100, 0), Vec3(0, -100)))
guideLine = [[Segment(Vec3(200, 0), Vec3(100, 0, 300)), Segment(Vec3(0, 100), Vec3(0, 100, 300)), Segment(Vec3(-200, 0), Vec3(-100, 0, 300)), Segment(Vec3(0, -100), Vec3(0, -100, 300))],
             [scale(0.5, 0.5)*Segment(Vec3(200, 0), Vec3(100, 0, 300)), scale(0.5, 0.5)*Segment(Vec3(0, 100), Vec3(0, 100, 300)), 
             scale(0.5, 0.5)*Segment(Vec3(-200, 0), Vec3(-100, 0, 300)), scale(0.5, 0.5)*Segment(Vec3(0, -100), Vec3(0, -100, 300))]]
lofted = Lofted(secBot, secTop)
create_geometry(trans(1000, 4000)*lofted)
