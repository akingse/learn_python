import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用
'''
# python1.0建模兼容接口
一堆模型，最右边的三根弯管比较显眼
'''
# ----------------------------------------------------------------------------

# 默认参数
# 圆弧
geo = scale(100)*Ellipse()
create_geometry(geo)
geo = scale(100)*Ellipse(Vec3(0, 0, 0),
                         Vec3(1, 0, 0), Vec3(0, 1, 0), 0, 1.5*pi)
create_geometry(translation(0, 200, 0)*geo)

# 线
geo = ContourLine()
geo = scale(5)*ContourLine(Vec2(10, -10), Arc(pi),
                           Vec2(-10, 00), Vec2(-10, -10), Vec2(10, -10))
create_geometry(geo)
geo = scale(10)*ContourLine([Vec2(10, -10), Arc(pi),
                             Vec2(-10, 00), Vec2(-10, -10), Vec2(10, -10)])
create_geometry(geo)

# 几种基本体
geo = scale(100)*Cone()
create_geometry(translation(200, 0, 0)*geo)
geo = scale(100)*Cone(Vec3(0, 0, 0), Vec3(0, 0, 1), 1, 0.7)
create_geometry(translation(200, 200, 0)*geo)

geo = scale(100)*Box()
create_geometry(translation(400, 0, 0)*geo)
Box(Vec3(0, 0, 0), Vec3(0, 0, 1.5), Vec3(
    1, 0, 0), Vec3(0, 1, 0), 1.2, 1.2, 1, 1)
create_geometry(translation(400, 200, 0)*geo)

geo = scale(100)*RuledSweep()
create_geometry(translation(600, 0, 0)*geo)
geo = scale(100)*RuledSweep([Vec3(0, 0, 0),  Vec3(2, 0, 0),  Vec3(3, 0, 0), Vec3(3, 2, 0), Vec3(0, 2, 0), Vec3(0, 1, 0)],
                            [Vec3(1, 0, 2),  Vec3(2, 0, 2),  Vec3(3, 1, 2), Vec3(3, 2, 2), Vec3(0, 2, 2), Vec3(0, 1, 2)])
create_geometry(translation(600, 400, 0)*geo)
geo = scale(100)*RuledSweepPlus()
create_geometry(translation(600, 200, 0)*geo)

geo = scale(10)*TorusPipe()
create_geometry(translation(800, 0, 0)*geo)
geo = scale(10)*TorusPipe(GeVec3d(0, 0, 0),
                          GeVec3d(1, 0, 0), GeVec3d(0, 1, 0), 10, 2, pi)
create_geometry(translation(800, 200, 0)*geo)

geo = scale(50)*RotationalSweep()
create_geometry(translation(1000, 0, 0)*geo)

geo = scale(100)*Extrusion()
create_geometry(translation(1200, 0, 0)*geo)
geo = scale(50)*ExtrusionPlus()
create_geometry(translation(1200, 200, 0)*geo)

geo = scale(10)*FilletPipe()
create_geometry(translation(1400, 0, 0)*geo)

geo = scale(20)*CurveLoft()
create_geometry(translation(2000, 400, 0)*geo)

sectionline = [Arc()]
keypoint = [Vec3(-10, 0, 0), Vec3(10, -10, 0),
            Vec3(20, 10, 0), Vec3(0, 0, 0), Vec3(-10, 0, 0)]
geo = scale(20)*CurveLoft(sectionline, keypoint, 50, 3).color(0, 191/255, 1, 1)
create_geometry(translation(2000, 200, 0)*geo)
