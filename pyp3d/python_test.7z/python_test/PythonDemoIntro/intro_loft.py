import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

# 新造型函数

# 函数名：loft_different
# 说明：不同形状截面的融合造型
# 入参：两个Section面
# 返回：Loft几何体
# 规则：
#   1，当其中一个Seciton为单一闭合线型时（比如一个Arc），两个Section起点终点分别对应，轮廓线等比例对应融合；
#   2，当两个Section都不是单一闭合线型时，两个Section轮廓线从各自起点开始，按照轮廓线数目一一对应，\
#      当其中一个Section有轮廓线段剩余时，将对应到另一个个Section的终点上。
# 备注：Loft类对于异面融合已研发完毕，下一个大版本将支持Loft异面融合

# 例子1
sec1 = Section(scale(100)*Arc())
sec2 = trans(0, 0, 200)*Section(Vec2(100, 0), Vec2(0, 100), Vec2(-100, 0))
loft1 = loft_different(sec1, sec2)
create_geometry(loft1)


# 例子2
sec1 = Section(Vec2(0, 0), Vec2(100, 0), Vec2(50, 80),)
sec2 = trans(0, 0, 100)*Section(Vec2(0, 0),
                                Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
loft2 = loft_different(sec1, sec2)
create_geometry(trans(300, 0)*loft2)


# 例子3
sec1 = Section(Vec2(0, -100), scale(100)*Arc(pi))
sec2 = trans(0, 0, 100)*Section(Vec2(0, -100), Vec2(100, 100), Vec2(-100, 100))
loft3 = loft_different(sec1, sec2)
create_geometry(trans(-300, 0)*loft3)
