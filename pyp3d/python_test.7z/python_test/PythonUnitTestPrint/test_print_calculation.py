import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

res = get_perimeter_of_polygon(
    [Vec3(0, 0), Vec3(100, 0), Vec3(100, 100), Vec3(0, 100)], False)
print_result(is_float_equal(res, 300))

res = get_perimeter_of_polygon(
    [Vec3(0, 0), Vec3(100, 0), Vec3(100, 100), Vec3(0, 100)], True)
print_result(is_float_equal(res, 400))

res = get_perimeter_of_polygon(
    [Vec3(0, 0), Vec3(100, 0), Vec3(100, 0), Vec3(0, 100)], True)
print_result(is_float_equal(res, 200+100*sqrt(2)))

res = get_perimeter_of_arc(Arc())
print_result(is_float_equal(res, 2*pi))
res = get_perimeter_of_arc(scale(100)*Arc(pi))
print_result(is_float_equal(res, 100*pi))


res = get_perimeter_of_fragment(Arc())
print_result(is_float_equal(res, 2*pi))


res = get_perimeter_of_line(Line(Arc()))
print_result(is_float_equal(res, 2*pi))

res = get_amount_of_line_segment(Line(Vec3(), Arc()))
print_result(res == 1)

# ----------------------------------------------------------
# 离散绘制
disNum = 10
line = Segment(Vec3(), Vec3(100, 0, 0))
res = get_discrete_points_from_segment(line, disNum)
print_result(len(res) == disNum)
create_geometry(line)
show_points_line(res)
line = scale(200)*Arc(pi)
res = get_discrete_points_from_arc(line, disNum)
print_result(len(res) == disNum)
create_geometry(line)
show_points_line(res)
line = SplineCurve([Vec3(), Vec3(100, 100, 0), Vec3(300, 0, 0)])
res = get_discrete_points_from_spline(line, disNum)
print_result(len(res) == disNum)
create_geometry(line)
show_points_line(res)
line = Line(Vec3(-100, 0, 0),  Vec3(100, 100, 0), Vec3(-100, 100, 0), )
res = get_discrete_points_from_line(line, disNum, False)
print_result(len(res) == disNum)
create_geometry(line)
show_points_line(res)
line = trans(0, -200)*Section(line)
res = get_discrete_points_from_section(line, disNum, False)
print_result(len(res) == disNum)
create_geometry(line)
show_points_line(res)


# 提取spline点集
spline = SplineCurve([Vec2(), Vec2(100, 100), Vec2(
    200, 0), Vec2(300, -100), Vec2(400, 0)], 10).color(1, 0, 0)
# spline=SplineCurve([Vec2(),Vec2(100,100),Vec2(200,0)],10).color(1,0,0)
points = get_discrete_points_from_spline(spline, 10, True)
# create_geometry(spline)
# show_points_line(points)

ctrlPoints = to_vec3(spline.points, spline.transformation)  # list乘矩阵
line = spline_curve_quasi(ctrlPoints, spline.num, spline.k)


# points=get_nested_parts_from_line(line)
# points=get_discrete_points_from_spline(spline,0,False)
line = Line(Vec2(0, -100), scale(150, 100)*Arc(pi))
# points=get_discrete_points_from_line(line,10,True,True)
# points=get_discrete_points_from_line(line,10,True,False)
points = get_discrete_points_from_line(line, 10, False, True)
# points=get_discrete_points_from_line(line,10,False,False)
# show_points_line(points)
# points=[Vec2(0,0),Vec2(100,10),Vec2(100,100),Vec2(0,100)]
# mat=get_matrix_from_points(points,True)
# mat=get_matrix_from_points(points,False)
# create_geometry(Line(points))
