
import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

# 数学函数测试
res = is_float_zero(10*PL_A, PL_E8)
print_result(res)
res = is_float_equal(1e6+1e-3, 1e6)
print_result(not res)


# 测试零
res = is_float_zero(0)
print_result(res)
res = is_float_zero(0, 0)
print_result(res)
res = is_float_zero(PL_A, 0)
print_result(not res)
res = is_float_zero(PL_B)
print_result(res)
res = is_float_zero(-PL_B)

res = is_float_equal(1, 1)
print_result(res)

res = is_float_equal(1, 1, PL_A)
print_result(res)

res = is_float_equal(0, 0)
print_result(res)

res = is_float_equal(1/PL_A, 1/PL_A)
print_result(res)

res = is_float_equal(PL_A, PL_A)
print_result(res)


# math_sign
res = math_sign(0) == 0
print_result(res)

res = math_sign(PL_A) == 0
print_result(not res)

res = math_sign(PL_B) == 0
print_result(res)

res = math_sign(11) == 1
print_result(res)

res = math_sign(0.0001) == 1
print_result(res)

res = math_sign(-0.0001) == -1
print_result(res)


# other
res = appro_num(PL_A)
print_result(res == 0)
res = appro_num(PL_E6)
print_result(not res == 0)
res = appro_num(2+PL_A)
print_result(res == 2)
num = 2+PL_A
# num=abs(round(num)-num)
# res=abs(abs(num / PL_E6)-round(abs(num/PL_E6)))

res = math_pytha(3, 4)
print_result(res == 5)

res = scale(100)*Sphere()-scale(100)*Cube()
# create_geometry(scale(100)*(Sphere()-Box()))
res = GeVec3d(50.0000000000001, 50.0000000000001, 0.0)
print_result(res == Vec3(50, 50))
print_result(is_coincident(res, Vec3(50, 50)))
