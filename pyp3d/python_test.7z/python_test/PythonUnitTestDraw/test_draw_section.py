import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用
'''
一些section
中间 2三角+2菱形+4拱形
四周 3三角，其中一个看起来像直线
'''
# ----------------------------------------------------------------------------

# 功能测试
# 新版section支持vec2和xy面的vec3，非xy面的vec3须用to_section转
text1 = Text('Section()').color(1, 1, 1, 1)
text1.size = 20
create_geometry(text1)
sect = scale(100)*Section()  # 默认不显示
create_geometry(sect)

# 正三角
a = Vec3(0, 0, 0)
b = Vec3(1, 0, 0)
c = Vec3(1, 1, 0)
l1 = [a, b, c]
t1 = (a, b, c)
# 倒三角
d = Vec2(0, 0)
e = Vec2(0, -1)
f = Vec2(1, 0)
l2 = [d, e, f]
t2 = (d, e, f)

text2 = Text('Section(*)')
text2.size = 20
create_geometry(trans(0, 150, 0)*text2)
create_geometry(trans(0, 150, 0)*scale(100)*Section(*l1))
create_geometry(trans(0, 100, 0)*scale(100)*Section(*l2))

text2 = Text('Section(list)')
text2.size = 20
create_geometry(trans(200, 0, 0)*text2)
create_geometry(trans(200, 0, 0)*scale(100)*Section(l1))
create_geometry(trans(200, 0, 0)*scale(100)*Section(l2))

text2 = Text('Section(tuple)')
text2.size = 20
create_geometry(trans(200, 150, 0)*text2)
create_geometry(trans(200, 150, 0)*scale(100) *
                Section(t1).color(0, 0.5, 0.5, 1))
create_geometry(trans(200, 150, 0)*scale(100) *
                Section(t2).color(0, 0.5, 0.5, 1))

# Arc()
l3 = [Vec2(-1, -1), Vec2(1, -1), Arc(pi)]
l4 = [Vec3(-1, -1, 0), Vec3(1, -1, 0), Arc(pi)]  # 自动连接，但不闭合
# l4=[Vec3(-1,-1,1),Vec3(1,-1,1),Arc(pi)]
# ln3=Section(l3) #判断维度
# ln4=Section(l4)
create_geometry(trans(0, -200, 0)*scale(100)*Section(l3))
create_geometry(trans(0, -400, 0)*scale(100)*Section(l4))

# append方法
ln1 = Section()
ln2 = Section()
for i in l3:
    ln1.append(i)
for i in l4:
    ln2.append(i)
create_geometry(trans(300, -200, 0)*scale(100)*ln1)
create_geometry(trans(300, -400, 0)*scale(100)*ln2)


# ----------------------------------------------------------------------------
# 矩阵测试
# translate()
# scale()
# compound matrix

text3 = Text('trans-rot')
text3.size = 20
create_geometry(trans(600, 600, 0)*text3)
sect1 = trans(800, 0, 0)*scale(100)*Section(*l1)
# rotate 旋转平移矩阵
T = arbitrary_rotate(Vec3(0, 0, 0), Vec3(0, 0, 1), pi/4)
create_geometry(T*sect1.color(0, 0.5, 0.5, 1))

# shear 错切矩阵
text4 = Text('shear sect')
text4.size = 20
create_geometry(trans(1000, 0, 0)*text4)
sect2 = scale(100)*Section(*l1)
T = trans(1000, 0, 0)*shearx(y=1, z=1)
create_geometry(T*sect2)

# reflect 反射矩阵
text5 = Text('reflect sect')
text5.size = 20
create_geometry(trans(-1000, 0, 0)*text5)
T = mirror(g_matrixE, 'XoZ')*mirror()
create_geometry(T*sect1.color(0, 0.5, 0.5, 1))

# while True:
#     sys.exit(0)
