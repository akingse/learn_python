import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

cube = scale(8)*Cube().colorRed()
array = Array(cube)
array.isinstance=True
N=11
for i in range(N):  # about 100p
    for j in range(N):
        array.append(trans(10*i, 10*j))
# create_geometry(array)

for i in range(129): #max=129
    array.append(trans(10*i,10))
create_geometry(array)


arrayNest=Array(array) #多层嵌套
for i in range(3):
    arrayNest.append(transz(i*10))
arrayNest.isinstance=True
# create_geometry(arrayNest)

# 镜像，支持
combine=Combine(Cube(),Sphere(),Cone())
# create_geometry(scale(10)*combine)

array=scale(10)*Array(combine)
# array.append(g_matrixE)
# create_geometry(array)


array2= Array(array)
array2.append(g_matrixE)
array2.append(transx(20))
# array2.append(mirror_xoy())
# create_geometry(array2)


exit()

clear_entity()
# 阵列
arrayList = Array(scale(100)*(Cube()-Sphere()))  # 阵列布尔体
for i in linspace(Vec3(0, 0, 0), Vec3(1000, 0, 0), 5):
    arrayList.append(trans(i))
create_geometry(arrayList)


# test array
cube = scale(8)*Cube()
cubes = trans(0, -500)*Combine()
for i in range(20):
    cubes.append(trans(10*i)*cube)
create_geometry(cubes)


array = Array(cube)
for i in range(10):  # about 100p
    for j in range(10):
        array.append(trans(10*i, 10*j))
create_geometry(array)
