import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用

'''
目前显示6个球
其中，球台，错切缩放，暂不支持
'''

# ----------------------------------------------------------------------------
# 功能测试
text1 = Text('Sphere()').color(1, 1, 1, 1)
text1.size = 20
create_geometry(trans(0, -150, 0)*text1)
sphere = scale(100)*Sphere()
create_geometry(sphere)

text2 = Text('color sphere')
text2.size = 20
create_geometry(trans(0, 150, 0)*text2)
create_geometry(trans(0, 300, 0)*sphere.color(0, 0.5, 0.5, 1))
sphere.color(0.5, 0.5, 0.5, 1)

text3 = Text('Sphere(c)')
text3.size = 20
create_geometry(trans(300, -150, 0)*text3)
c = Vec3(3, 0, 0)
create_geometry(scale(100)*Sphere(c))

text = Text('Sphere(c,r)')
text.size = 20
create_geometry(trans(600, -150, 0)*text)
c = Vec3(6, 0, 0)
create_geometry(scale(100)*Sphere(c, 1.2))

# 球台（暂不支持）
text = Text('Sphere(c,r,l,u)')
text.size = 20
create_geometry(trans(900, -150, 0)*text)
c = Vec3(9, 0, 0)
# createGeometry(scale(100)*Sphere(c,1.3,0.1,3))

# ----------------------------------------------------------------------------
# 矩阵测试
# translate()
# scale()

# compound matrix
text3 = Text('trans sphere')
text3.size = 20
create_geometry(trans(300, 200, 0)*text3)
sphere1 = trans(500, 0, 0)*scale(100)*Sphere()
# rotate 旋转平移矩阵
T = arbitrary_rotate(Vec3(0, 0, 0), Vec3(0, 0, 1), pi/4)
create_geometry(T*sphere1.color(0, 0.5, 0.5, 1))

# shear 错切矩阵 （暂不支持）
text4 = Text('shear sphere')
text4.size = 20
create_geometry(trans(900, 0, 0)*text4)
T = trans(900, 0, 0)*sheary(x=1, z=1)
# createGeometry(T*sphere)

# reflect 反射矩阵
text5 = Text('reflect sphere')
text5.size = 20
create_geometry(trans(-100, -300, 0)*text5)
sphere = scale(100)*Sphere(Vec3(2, 2, 2))
T = mirror(g_matrixE, 'XoZ')*mirror()
create_geometry(T*sphere.color(0, 0.5, 0.5, 1))
