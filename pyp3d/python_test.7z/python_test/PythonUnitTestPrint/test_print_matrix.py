import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

# 测试 GeTransform基本数据类型
# 矩阵基本运算
a = trans(1, 2, 3)
b = trans(1, 2, 3)
# 重载 ==
print_result(a == b)
print_result(not (a < b))
print_result((trans(1, 2, 1) < b))


# 单位正交矩阵
res = is_identify_matrix(GeTransform())
print_result(res)

res = is_identify_matrix(trans(1, 2))
print_result(not res)

res = is_orthogonal_matrix(GeTransform())
print_result(res)

res = is_orthogonal_matrix(rotz(pi/3), False)
print_result(res)

res = is_orthogonal_matrix(rotz(pi/3)*trans(1, 3), True)
print_result(res)

res = is_orthogonal_matrix(rotz(pi/3)*trans(1, 3), False)
print_result(not res)

res = is_identify_matrix(rotz(pi/100))
print_result(not res)

# 验证左乘
testM = trans(1, 3, 5)*rotz(pi/3)*trans(1, 2, 3)*rotz(pi/4)
# print_matrix(testM)
# print_matrix(inverse(testM))
# print_matrix(inverse_std(testM))
# print_matrix(testM*inverse_std(testM))

# 参数兼容
mat = scale()
mat = scale(2)
mat = scale(1, 2)
mat = scale((1, 2))
mat = scale(2, 3, 4)
mat = scale((2, 3, 4))
mat = scale(Vec2(1, 2))
mat = scale(Vec3(1, 2, 3))

mat = trans()
mat = trans(1, 2)
mat = trans(2, 3, 4)
mat = trans(Vec2(1, 2))
mat = trans(Vec3(1, 2, 3))

lst = linspace(Vec2(1, 0), Vec2(2, 0), 2)  # with end有终点吗
lst = linspace(Vec2(1, 0), Vec2(2, 0), 2)
lst = linspace(Vec2(1, 0), Vec2(2, 0), 3)
lst = linspace(Vec2(1, 0), Vec2(2, 0), 3)
# print_matrix(GeTransform())


'''
测试矩阵，无图形输出
python terminal输出单位矩阵 M*M^(-1)=E
'''

# # ----------------------------------------------------------------------------
# # 测试函数和类的参数，兼容性和限制
# #
a = [11, 12, 13]
b = (21, 22, 23)
c = [31, 32]
d = (41, 42)
e = Vec3(51, 52, 53)
f = Vec2(61, 62)

# Point参数
p1 = Point(a)
p2 = Point(b)
p3 = Point(c)
p4 = Point(d)
p5 = Point(*a)
p6 = Point(*b)

# translate
M = trans(a)
M = trans(b)
M = trans(c)
M = trans(d)
M = trans(e)
M = trans(f)
M = trans(*a)
M = trans(*c)

# scale
M = scale(a)
M = scale(b)
M = scale(c)
M = scale(d)
M = scale(*a)
M = scale(*c)

# rotate
a = pi/2
M = rotate(a)
M = rotate(Vec3(0, 0, 1), a)
print_result(M == rotz(a))
M = rotate(Vec3(0, 0, 1))
print_result(M == rotz(0))

# 逆矩阵
M = rotate(1)  # len()==1,scope，默认z轴
M = GeTransform([[1, 0, 5, 0], [2, 1, 6, 0], [3, 4, 0, 0]])
M = GeTransform()
print_result(is_identify_matrix(M))
M = trans(1, 2, 3)
print_result(is_identify_matrix(inverse_orth(M)*M))

M = scale(1, 2, 3)*rotate(pi/3)*trans(1, 2, 3)
print_result(is_identify_matrix(inverse(M)*M))
M = trans(4, 5, 6)*scale(1, 2, 3)*rotate(Vec3(1, 2, 1), pi/3)*trans(1, 2, 3)
print_result(is_identify_matrix(inverse(M)*M))
M = rotate(pi/3)*trans(1, 2, 3)
print_result(is_identify_matrix(inverse_orth(M)*M))
M = trans(1, 2, 3)*rotate(pi/3)
print_result(is_identify_matrix(inverse_orth(M)*M))
# print(M)
Mi = inverse(M)
print_result(is_identify_matrix(Mi*M))

# print(Mi)
M = shearx(y=1, z=2)*sheary(x=3, z=4)
M = mirror(g_matrixE, 'XoZ')*mirror()
# print_matrix(M*inverse(M))
# print_matrix(M*inverse_orth(M))
# ------------------------------------------------------------------


# 提取矩阵
points = [Vec3(0, 0), Vec3(100, -20), Vec3(0, -100, 0)]
show_points_line(points)
pts2 = inverse_orth(get_matrix_from_three_points(points, False))*points
show_points_line(pts2)
sec = Section(roty(pi/3)*trans(0, 10)*scale(20)*Arc())
mat = get_matrix_from_three_points(points, False)
for iter in points:
    print_result(is_point_on_plane(iter, mat))
mat = get_matrix_from_three_points(points, True)
for iter in points:
    print_result(is_point_on_plane(iter, mat))
secSha = shadow_vector_matrix_2D(
    get_matrixs_axisz(mat))*sec
secRela = inverse_orth(mat)*secSha


# 测试多点矩阵
pList = [Vec3(0, 0), Vec3(1, 1), Vec3(1, 0),
         Vec3(0, 0), Vec3(1, 1), Vec3(1, 0)]
res = remove_coincident_point(pList, True)
# plist = [Vec3(0, 0), Vec3(10, 0), Vec3(10, 20), ]
plist = [Vec3(0, 0), Vec3(0, 0), Vec3(0, 5), Vec3(10, 10)]
mat = get_matrix_from_points(plist)
for iter in plist:
    print_result(is_point_on_plane(iter, mat))

# mat=get_matrix_from_two_points([Vec3(0,0,0),Vec3(0,0,10)], False)
# mat=get_matrix_from_two_points([Vec3(0,0,0),Vec3(10,10,0)], True)
# mat=get_matrix_from_two_points([Vec3(0,0,0),Vec3(0,10,10)], True)
mat = get_matrix_from_two_vectors(Vec3(3, 1, 0), Vec3(30, 20, 0))
pns = [Vec3(10, 0, 0), Vec3(20, 10, 0), Vec3(0, 30, 20)]
# mat=get_matrix_from_points(pns)
mat = get_matrix_from_three_points(pns)
# mat=get_matrix_from_line
# create_geometry(mat*show_coordinate_system())
res = is_orthogonal_matrix(mat)
print_result(res)
# create_geometry(mat*coordinate_system())
# create_geometry(scale(100)*Cone(Vec3(0,0,0),Vec3(3,1,0)))


# 投影矩阵
for i in range(11):
    mat = shadow_vector_matrix_2D(Vec3(1, 1, 0))
    # create_geometry(mat*translate(0, 0, 10*i)*sec)
# create_geometry(scale(100)*vector_shadow(Vec3(0, 0.1, 1))
#                 * Cube().colorRand())
res = is_orthogonal_matrix(rotx(pi/3)*roty(pi/4)*rotz(pi/6))
print_result(res)

mat = scale(1, 2, 3)
res = is_orthogonal_matrix(mat)
print_result(not res)
mat = get_orthogonal_matrix(mat)
res = is_orthogonal_matrix(mat)
print_result(res)

res = is_two_dimensional_matrix(trans(10, 10))
print_result(res)
res = is_two_dimensional_matrix(trans(10, 10, 10))
print_result(not res)

res = is_identify_matrix(g_matrixE)
print_result(res)
res = is_zero_matrix(g_matrixO)
print_result(res)
