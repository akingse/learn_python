import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

# 测试平台几何镜像矩阵支持
matMi = mirror(trans(-100)*rotz(-pi/6))
matSh = shearz(1, 1)
matSc = scale(1, 2, 3)
geo = Text('abc123中文')
geo.font_name = "宋体"
geo.size = 100
geo = scale(100)*Sphere()  # 仅支持镜像
geo = scale(100)*Cube()  # 全支持
geo = scale(100)*Arc(pi)  # 全支持
geo = Cone(Vec3(), Vec3(0, 0, 200), 100, 80)  # 全支持
geo = Loft(Section(Vec3(0, 0, ), Vec3(100, 0, 0), Vec3(0, 100, 0)),
           Section(Vec3(0, 0, 200), Vec3(100, 0, 200), Vec3(0, 100, 200)))  # 全支持
geo = Sweep(Section(Vec3(0, 0, ), Vec3(100, 0, 0), Vec3(0, 100, 0)),
            Line(Vec3(0, 0, ), Vec3(0, 0, 200)))  # 全支持
geo = Sweep(trans(100)*rotx(pi/2)*Section(Vec3(0, 0, ), Vec3(100, 0, 0), Vec3(0, 100, 0)),
            Line(Arc(pi)))
geo = Sweep(trans(100)*rotx(pi/2)*Section(trans(50, 50)*scale(50)*Arc()),
            Line(Arc(pi)))  # 缩放有问题
create_geometry(trans(0, -1000)*trans(-100, -100)*geo)
create_geometry(trans(0, -1000)*matMi*geo.colorRed())
create_geometry(trans(0, -1000)*matSh*geo.colorGreen())
create_geometry(trans(0, -1000)*matSc*geo.colorBlue())

# 球 非等轴缩放 不行
# 圆弧 扫掠体 非等轴缩放 不行

# ------------------------------------------------------------------------------------------------
# 镜像矩阵
mir = mirror_of_plane("YZ")
show_coordinate_system(mir*trans(200, 100))


coor = show_coordinate_system(trans(200, 0, 100), 1, 1)
mir = mirror(roty(pi/6))
show_coordinate_plane(roty(pi/6)*trans(0, 0, 50)*rotz(pi/2))
show_coordinate_plane(rotz(pi/2)*trans(0, 0, 50)*roty(pi/6))
show_coordinate_plane(mir)
create_geometry(coor)
create_geometry(mir*coor)
mirM = GeTransform([[-1, 0, 0, 0], [0, -1, 0, 0], [0, 0, 1, 0]])

geo = show_coordinate_system(mirM, 1, 1)
mat = shadow_vector_matrix_2D(Vec3(2, 1, 0))
create_geometry(mat*geo)
