import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

# 新造型函数

# 函数名：sweep_surround_lines
# 说明：多条线包围而成的几何体
# 入参：多个（大于等于3）Line或Line的列表
# 返回：Loft几何体

# 例子1
lines = [Line(trans(50, 0, 0)*scale(100)*Arc(0.5*pi)), Line(trans(0, 0, 0)
                                                            * scale(50)*Arc(0.5*pi)), Line(trans(25, 0, 25)*scale(70)*Arc(0.7*pi))]
geo = sweep_surround_lines(lines)
create_geometry(geo)

# 例子2
lines = [Line(Vec3(0, 0, 0), Vec3(0, 0, 200)), Line(
    Vec3(100, 0, 0), Vec3(100, 20, 200)), Line(Vec3(0, 100, 0), Vec3(0, 150, 200))]
geo = sweep_surround_lines(lines)
create_geometry(trans(300, 0)*geo)

# 例子3
lines = [Line(SplineCurve([Vec3(0, 0, 0), Vec3(0, 0, 200), Vec3(-50, 0, 300)])),
         Line(SplineCurve([Vec3(100, 0, 0), Vec3(
             100, 20, 200), Vec3(150, 0, 300)])),
         Line(SplineCurve([Vec3(0, 100, 0), Vec3(0, 150, 200), Vec3(0, 200, 300)]))]
geo = sweep_surround_lines(lines)
create_geometry(trans(-300, 0)*geo)

# ---------------------------------------------------------------

# 函数名：arc_correspond_point_sweep
# 说明：点和圆弧一一对应的扫掠几何体
# 入参：两个Section，section1放多个点（大于等于3），section1放数量相同的圆弧
# 返回：Loft几何体

# 例子1
sec1 = scale(100)*Section(Arc(Vec3(0, 1, 0), Vec3(0, 0, 0), Vec3(1, 0, 0)), Arc(Vec3(2, 0, 0), Vec3(2.1, 0.1, 0), Vec3(2, 0.2, 0)),
                          Arc(Vec3(0.2, 2, 0), Vec3(0.1, 2.1, 0), Vec3(0, 2, 0)))
sec2 = scale(100)*trans(0, 0, 2) * \
    Section(Vec3(0, 0, 0), Vec3(2, 0, 0), Vec3(0, 2, 0))
geo = arc_correspond_point_sweep(sec1, sec2)
create_geometry(geo)

# 例子2
sec3 = Section(Vec2(0, 0), Vec2(100, 0), Vec2(100, 100))
sec4 = trans(0, 0, 200)*Section(scale(10)*rotz(2*pi/3)*Arc(pi), trans(100, 0)
                                * scale(10)*rotz(-2*pi/3)*Arc(pi), trans(100, 100)*scale(10)*Arc(pi))
geo = arc_correspond_point_sweep(sec3, sec4)
create_geometry(geo)


# -----------------------------------------------------

# sec=trans(0,0)*rotz(pi/6)*roty(pi/2)*Section(Vec2(100,-100),Vec2(0,100),Vec2(-100,-100))
sec = trans(0, 0, 0)*roty(pi/2)*Section(Vec2(100, -100),
                                        Vec2(0, 100), Vec2(-100, -100))
# sec=trans(0,-30,0)*scale(50)*roty(pi/2)*Section(Arc(pi),Vec2(-1,-1),Vec2(0,-2),Vec2(1,-1))
# sec=trans(0,-30,0)*scale(50)*roty(pi/2)*Section(Arc())
# create_geometry(sec)
line = Line(Vec3(0, 0, 0), Vec3(300, 100, 0), Vec3(
    800, 300, 0), Vec3(900, 300, 100), Vec3(600, -300, 0))
line = Line(Vec3(0, 0, 0), Vec3(300, 100, 0), Vec3(
    800, 300, 0), Vec3(900, 300, 100))  # ,Vec3(600,-300,0))
# line=Line(Vec3(0,0,0),scale(1000)*Arc(pi))
# create_geometry(line)

# ss=sweep_stere(sec,line)
# create_geometry(ss)

# ss=Sweep(sec,line)
# create_geometry(ss)

sec = Section(trans(100, 0)*scale(100)*rotz(-pi/2)*Arc(pi), Vec3(0, 50),
              trans(-100, 0)*scale(100)*rotz(pi/2)*Arc(pi), Vec3(0, -50))
sp_y = SplineCurve([Vec3(0, 50, 0), Vec3(0, 20, 100), Vec3(0, 100, 300)], 10)
sp_x = SplineCurve([Vec3(200, 0, 0), Vec3(20, 0, 100), Vec3(100, 0, 200)], 10)
# create_geometry(sp_y)
pns = sweep_guide_line(sec, sp_x, sp_y)
# create_geometry(Line(pns))
# create_geometry(spline_curve_quasi([Vec3(0,0,0),Vec3(0,0,200),Vec3(0,0,300)]))
