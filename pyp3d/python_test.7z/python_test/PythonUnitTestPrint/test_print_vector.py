import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

# 测试 GeVec3d, GeVec3d, GeTransform基本数据类型
# test new vecter operator
v1 = dot(Vec3(2, 1), Vec3(3, 4))
v2 = cross(Vec3(2, 1), Vec3(3, 4))
v3 = Vec3(2, 1) * Vec3(3, 4)
v4 = Vec3(2, 1) ^ Vec3(3, 4)
print_result(v1 == v3)
print_result(v2 == v4)

# 测试夹角
ang = get_angle_of_two_vectors(Vec3(100, 0), Vec3(100, -100, 0))
print_result(is_float_equal(ang, -pi/4))

vec = Vec2(6, 8)
v1 = vec.norm()
v2 = vec.unitize()
print_result(vec.norm() == 10)


# 内置类型
vec = Vec3()
vec0 = unitize(vec)
pv0 = PosVec(Vec3(1, 1), Vec3(2, 2))
print_result(pv0.m_position == Vec3(1, 1))
print_result(pv0.m_vector == Vec3(2, 2))
print_result(pv0.pos == Vec3(1, 1))
print_result(pv0.vec == Vec3(2, 2).unitize())

# pv1 = PosVec([Vec3(1, 1), Vec3(2, 2)])
# pv2 = PosVec(Segment(Vec3(1, 0), Vec3(2, 2)))
pv0 = to_pos_vec(Vec3(1, 1), Vec3(2, 2))
pv1 = to_pos_vec([Vec3(1, 1), Vec3(2, 2)])
pv2 = to_pos_vec(Segment(Vec3(1, 0), Vec3(2, 2)))

# 测试pyp3d_vector，矢量相关
r1 = cross(Vec2(1, 0), Vec2(0, 1))
r1 = cross(Vec2(1, 0), Vec2(1, 0))
r1 = cross(Vec2(1, 0), Vec2(-1, 0))

points = [Vec2(0, 0), Vec2(1, 0), Vec2(-1, 0), Vec2(1, 1), ]
pp = remove_collinear_point(points)

pointA = Vec2(0, 0)
pointB = Vec2(1, 0)
pointC = Vec2(-1, 0)
a = norm(pointA-pointB)*norm(pointC-pointB)
b = dot(pointA-pointB, pointC-pointB)

res = norm(pointA-pointB)*norm(pointC -
                               pointB) > abs(dot(pointA-pointB, pointC-pointB))
print_result(not res)


ves = Vec2()+Vec2()
ves = Vec2()-Vec2()
ves = Vec3()+Vec3()
ves = Vec3()-Vec3()

ves = Vec2(1, 2)+Vec3(3, 4)
ves = Vec2(1, 2)-Vec3(3, 4)
ves = Vec3(1, 2)+Vec2(3, 4)
ves = Vec3(1, 2)-Vec2(3, 4)


res = dot(Vec3(1, 0), Vec3(2, 0))
res = dot(Vec3(1, 0), Vec3(-2, 0))


a = Vec2(1, 1)
b = a
print_result(a == b)
print_result(not a == Vec2(1, 1))


# 矢量乘矩阵
# vec3得vec3
# vec2得vec2
v3 = Vec3(1, 0, 0)
v2 = Vec2(1, 0)
vn3 = trans(1, 2, 3)*rotz(pi/2)*v3
vn2 = trans(1, 2, 3)*rotz(pi/2)*v2
print_result(isinstance(vn2, GeVec3d))
print_result(isinstance(vn3, GeVec3d))
# vec转换
v2 = [Vec2(1, 2), Vec2(0, 0), Vec2(1, 0), Vec2(0, 2)]  # 实测没有改值
vn3 = to_vec3(v2, rotz(pi/2))
p3 = trans(1, 2, 3)*Vec2(1, 1)
print_result(p3 == Vec3(1, 2, 3)+Vec3(1, 1))

v2 = Vec2(1, 2)
p = unitize(v2)
v2 = Vec2(0, 0)
p = unitize(v2)
v3 = Vec3(1, 2, 3)
p = unitize(v3)
v3 = Vec3()
p = unitize(v3)
print_result(v3 == p)

# 测试 pyp3d_point_set点集计算
ali = [1, [2, 3], [4, 5, 6, [7, 8, 9]]]
nal = get_nested_parts_from_list(ali)
print_result(len(nal) == 9)

v1 = Vec2(0, 0)
v2 = Vec2(2, 0)
v3 = Vec2(1, 1)
tra0 = is_point_in_triangle(Vec2(1, 0.5), [v1, v2, v3])
tra1 = is_point_in_triangle(Vec2(1, 1), [v1, v2, v3])
tra2 = is_point_in_triangle(Vec2(1.6, 0.5), [v1, v2, v3])
print_result(tra0)
print_result(tra1)
print_result(not tra2)

# --------------------------------------------------------------------------
# pyp3d_vector

vList = [Vec2(0, 0), Vec3(0, 0), Vec2(2, 2), [Vec2(0, 0)]]
print_result(is_all_vec(vList))
vList = [Vec2(0, 0), Vec3(0, 0), Vec2(2, 2), [Vec2(0, 0)], Arc()]
print_result(not is_all_vec(vList))
alist = [1, [2, 3], [4, 5, 6, [7, 8, 9]]]
print_result(is_all_num(alist))


print_result(is_perpendi(Vec2(0, 0), Vec3(0, 0)))
print_result(is_perpendi(Vec2(0, 0), Vec3(1, 0)))
print_result(is_perpendi(Vec2(1, 2), Vec3(-2, 1)))
print_result(not is_perpendi(Vec2(1, 1), Vec3(1, 1)))
print_result(is_perpendi(Vec2(3, 1), rotz(pi/2)*Vec3(3, 1)))
print_result(is_perpendi(Vec2(0, 10), rotx(pi/2)*Vec3(3, 1)))

print_result(is_parallel(Vec2(0, 0), Vec3(0, 0)))
print_result(is_parallel(Vec2(0, 0), Vec3(1, 0)))
print_result(is_parallel(Vec2(1, 2), Vec3(-1, -2)))
print_result(not is_parallel(Vec2(1, 1), Vec3(1, 2)))
print_result(is_parallel(Vec2(3, 1), rotz(pi)*Vec3(3, 1)))
print_result(not is_parallel(Vec2(2, 3), trans(pi/2, 0)*Vec3(2, 3)))

print_result(is_coincident(Vec2(0, 0), Vec3(0, 0)))
print_result(is_coincident(Vec3(2, 0), Vec3(2, 0)))
print_result(is_coincident(Vec3(0, 0), trans(0, -2)*rotz(pi/2)*Vec3(2, 0)))
# print(trans(0, -2)*rotz(pi/2)*Vec3(2, 0))
