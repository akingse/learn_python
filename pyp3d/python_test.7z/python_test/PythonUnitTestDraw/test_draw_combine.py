import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用

'''
list嵌套自动转combine
2球
4长方体

'''
# ----------------------------------------------------------------------------

# 测试combine

b1 = trans(1, 0, 0)*Box()
b2 = trans(2, 0, 0)*Box()
b3 = trans(3, 0, 0)*Box()
b4 = trans(4, 0, 0)*Box()
b5 = trans(5, 0, 0)*Box()

s1 = trans(0, 0, 1)*Sphere()
s2 = trans(0, 0, 2)*Sphere()
s3 = trans(0, 0, 3)*Sphere()
s4 = trans(0, 0, 4)*Sphere()
s5 = trans(0, 0, 5)*Sphere()


c = Combine([b1, [b2, [b3, b4]], b5])
create_geometry(trans(0, 0, 0)*scale(100)*c)
c = c.color(0, 0.5, 0.5, 1)
create_geometry(trans(0, -200, 0)*scale(100)*c)

b = [b1, [b2, Combine(b3, [b4, b5])]]
b = Combine(b)
create_geometry(trans(1000, 0, 0)*scale(100)*b)

s = [s1, [s2, [s3, s4], s5]]
c = Combine(s)
create_geometry(trans(0, 200, 0)*scale(100)*c)

c = Combine(b, [s]).color(1, 0, 0)
create_geometry(trans(500, 200, 0)*scale(100)*c)


# while True:
#     sys.exit(0)
