import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用

'''
十字排列
6+5=11
'''


# ----------------------------------------------------------------------------
# 功能测试

text1 = Text('Loft()').color(1, 1, 1, 1)
text1.size = 20
create_geometry(trans(100, 0, 0)*text1)
section_0 = translation(200, 0, 0)*Section(Vec2(0, 0),
                                           Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section_1 = translation(200, 0, 0)*Section(Vec2(80, 80),
                                           Vec2(60, 80), Vec2(60, 60), Vec2(80, 60))
section_2 = translation(200, 0, 0)*Section(Vec2(50, 50),
                                           Vec2(20, 50), Vec2(20, 20), Vec2(50, 20))

sectionD = section_0 - section_1 - section_2
sectionU = translation(0, 0, 100)*sectionD
loft = Loft(sectionD, sectionU)
create_geometry(loft)

text = Text('to_section').color(1, 1, 1, 1)
text.size = 20
create_geometry(trans(-100, 0, 0)*text)
sectionD = to_section(
    Vec3(0, 0, 0),
    Vec3(1, 0, 0),
    Vec3(1, 1, 1),)
sectionU = translation(0, 0, 1)*sectionD
create_geometry(trans(-200, 0, 0)*scale(100)*Loft(sectionD, sectionU))

# 实现sweep圆弧扫掠
section = scale(0.1)*Section(Vec2(100, -100), scale(100) *
                             Arc(0.5*pi), Vec2(-100, 100), Vec2(-100, -100))
sectionList = [section]
t = 100
for i in range(1, t+1):
    sectionList.append(arbitrary_rotate(
        Vec3(-100, 0, 0), Vec3(0, -1, 0), i/t*pi/2)*section)
loft = scale(2)*Loft(*sectionList)
loft.smooth = True
create_geometry(loft)

# 布尔测试（vec2）
sectionA1 = Section(
    Vec2(0, 0),
    Vec2(1, 0),
    Vec2(1, 1),
    Vec2(0, 1))
sectionA2 = Section(
    Vec2(0, 0),
    Vec2(1/2, 0),
    Vec2(1/2, 1/2),
    Vec2(0, 1/2))
sectionA = sectionA1-sectionA2
sectionB = trans(0, 0, 1)*sectionA
loft = scale(100)*Loft(sectionA, sectionB)
create_geometry(loft)

# 布尔测试（vec3）
sectionA1 = to_section(
    Vec3(0, 0, 1),
    Vec3(1, 0, 1),
    Vec3(1, 1, 1),
    Vec3(0, 1, 1))
sectionA2 = to_section(
    Vec3(0, 0, 1),
    Vec3(1/2, 0, 1),
    Vec3(1/2, 1/2, 1),
    Vec3(0, 1/2, 1))
sectionA = sectionA1-sectionA2
sectionB1 = trans(0, 0, 2)*sectionA1
sectionB2 = trans(0, 0, 2)*sectionA2
sectionB = scale(0.8)*(sectionB1-sectionB2)
loft = scale(100)*Loft(sectionA, sectionB)
create_geometry(loft)


# ----------------------------------------------------------------------------------------
# 布尔运算（line-loft）
section1 = Section(
    Vec2(0, 0),
    Vec2(1, 0),
    Vec2(1, 1),
    Vec2(0, 1))
section2 = trans(0, -0.5, 0)*Section(
    Vec2(0, 0),
    Vec2(2, 0),
    Vec2(2, 1),
    Vec2(0, 1))
section3 = Section(Arc())
section = section1 + section2 + section3  # v
# section=section1 + section2   #v
# section=section1 - section2   #v
# section=section2 - section1   #v
# section=section1 + section3   #v
# section=section1 - section3   #v
# section=section3 - section1   #v
# section=section2 + section3   #v
# section=section2 - section3   #
sectionD = section
sectionU = trans(0, 0, 1)*section
loft = trans(500, 0, 0)*scale(100)*Loft(sectionD, sectionU)
create_geometry(loft)

# section=section1 - section2 - section3 #v
# section=section2 - section1 + section3 #
# section=section1 - section2 + section3 #
section = section1 + section3 - section2
sectionD = section
sectionU = trans(0, 0, 1)*section
loft = trans(1000, 0, 0)*scale(100)*Loft(sectionD, sectionU)
create_geometry(loft)


# XY面
# section_0 = Section(Vec2(0,0), Vec2(100,0), Vec2(100,100), Vec2(0,100))
# section_1 = Section(Vec2(80,80), Vec2(60,80), Vec2(60,60), Vec2(80,60))
# section_2 = Section(Vec2(50,50), Vec2(20,50), Vec2(20,20), Vec2(50,20))
# line = Line(Vec3(0,0,0),Vec3(0,0,200))
# YZ面
section_0 = rotate(g_axisY, 0.5*pi) * Section(Vec2(0, 0),
                                              Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section_1 = rotate(g_axisY, 0.5*pi) * Section(Vec2(80, 80),
                                              Vec2(60, 80), Vec2(60, 60), Vec2(80, 60))
section_2 = rotate(g_axisY, 0.5*pi) * Section(Vec2(50, 50),
                                              Vec2(20, 50), Vec2(20, 20), Vec2(50, 20))
line = Line(Vec3(0, 0, 0), Vec3(100, 0, 0))
sectionD = section_0-section_1-section_2
sectionU = trans(100, 0, 0)*sectionD
loft = trans(0, -200, 0)*scale(1)*Loft(sectionD, sectionU)
create_geometry(loft)

# XZ面 line
section_0 = rotate(Vec3(1, 0, 0), 0.5*pi) * Section(Vec2(0, 0),
                                                    Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section_1 = rotate(Vec3(1, 0, 0), 0.5*pi) * Section(Vec2(80,
                                                         80), Vec2(60, 80), Vec2(60, 60), Vec2(80, 60))
section_2 = rotate(Vec3(1, 0, 0), 0.5*pi) * Section(Vec2(50, 50),
                                                    Vec2(20, 50), Vec2(-20, -20), Vec2(50, 20))
line = Line(Vec3(0, 0, 0), Vec3(0, 100, 0))
sectionD = section_0-section_1-section_2
sectionU = trans(0, 100, 0)*sectionD
loft = trans(0, -600, 0)*scale(1)*Loft(sectionD, sectionU)
create_geometry(loft)


# 矩阵作用
section1 = Section(Vec2(0, 0), Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section2 = Section(Vec2(0, 0), Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
sectionD = trans(-50, -50)*section1-scale(0.4)*section2
sectionU = trans(0, 0, 100)*sectionD
loft1 = Loft(sectionD, sectionU)  # 面（布尔前） 矩阵
create_geometry(trans(0, 400, 0)*scale(1)*loft1)

sectionD = roty(-pi/2)*(trans(-50, -50)*section1+section2)
sectionU = trans(100, 0, 0)*sectionD
loft2 = Loft(sectionD, sectionU)  # 面（布尔后） 矩阵
create_geometry(trans(0, 600, 0)*scale(1)*loft2)

sectionD = rotx(pi/2)*section1
sectionU = trans(0, 100, 0)*sectionD
loft3 = scale(2)*Loft(sectionD, sectionU)  # 体 缩放矩阵
create_geometry(trans(0, 800, 0)*scale(1)*loft3)
