import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用


'''
看起来有点费眼睛，不报错就行
# 共10个点，其中有一个在原点，难以辨认（point无法缩放）
'''

# ----------------------------------------------------------------------------
# 功能测试
create_geometry(Point())  # 默认点 Point(0,0,0)

text1 = Text('point').color(1, 1, 1, 1)
# text1.size=1
# createGeometry(text1)
create_geometry(Point(1, 0))
create_geometry(Point(1, 1, 0))

list2 = [2, 0]
list3 = [3, 0, 0]
tuple2 = (2, 1)
tuple3 = (3, 1)
create_geometry(Point(list2))
create_geometry(Point(list3))
create_geometry(Point(tuple2))
create_geometry(Point(tuple3))


# ----------------------------------------------------------------------------
# 矩阵测试
# translate()
point = Point(0, 0, 0)
create_geometry(trans(2, -1, 0)*point)

# rotate 旋转平移矩阵
T = arbitrary_rotate(Vec3(0, 0, 0), Vec3(0, 0, 1), pi/2)
create_geometry(T*trans(2, -1, 0)*point)

# reflect 反射矩阵
T = mirror(g_matrixE, 'XoZ')*mirror()
create_geometry(T*trans(1, 1, 0)*point)
