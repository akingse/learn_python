import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *


# 三点组成线段，倒角圆弧
points = [Vec3(0, 0), Vec3(200, 0), Vec3(300, 300)]
R = 100
arc1 = arc_of_segments_bevel(points, R)
# create_geometry(Line(points))
# show_arc_direction(arc1)
# create_geometry(arc1)


# 与两个圆外切的圆弧
# 半径R=0时返回公共切线
# isCcw控制返回arc是否为逆时针（True为逆时针）
arcA = trans(0)*scale(150)*Arc()
arcB = trans(300, 0)*scale(130)*Arc()
# create_geometry(arcA)
# create_geometry(arcB)
# 返回直线
# arc2 = arc_of_two_excircles(arcA, arcB, 0, False)
# show_points_line(arc2)
# 返回圆弧
# arc2 = arc_of_two_excircles(arcA, arcB, 100, True)
# show_arc_direction(arc2)


# 设定长轴短轴、起始角终止角的标准椭圆
# isCcw控制是否为逆时针，isAlpha控制是否为圆心角
a = 200
b = 100
# arc3 = arc_of_oval_angle(a, b, radians(30), radians(180))
arc3 = arc_of_oval_angle(a, b, radians(0), radians(180))
arc3 = arc_of_oval_angle(a, b, radians(0), radians(-60), False)
# show_arc_direction(arc3)


# 圆弧反转
# reCcw反转方向，reScope反转扫掠角度
arc = arc_of_three_points(Vec2(100, 0), Vec3(130, 130, 50), Vec2(0, 100))
arc4 = arc_reverse(arc, True, False)
arc4 = arc_reverse(arc, False, True)
arc4 = arc_reverse(arc, True, True)


# 通过线段打断Arc
arc = scale(100)*rotz(0*pi)*Arc(-pi)  # +pi
# create_geometry(arc)
# line1 = Segment(Vec2(), Vec3(100, -50))
# show_points_line(line1.list)
# arc5 = arc_of_segment_interrupt(line1, arc, False)
# show_arc_direction(arc5)

# line2 = Segment(Vec2(), Vec3(-150, 50))
# show_points_line(line2.list)
# arcM = arc_of_segment_interrupt(line2, arc, False)
# show_arc_direction(arc5)


# 圆心缩放
arc6 = trans(200, 100)*scale(50)*Arc(pi)
# show_arc_direction(arc6)
# arc6.scale_center(2)
# show_arc_direction(arc6)


arc = scale(200, 100)*Arc(pi)
create_geometry(arc)
disarc = get_discrete_points_from_arc(arc, 10, True, True)
# disarc=get_discrete_points_from_arc(arc,4,False)
show_points_line(disarc)
