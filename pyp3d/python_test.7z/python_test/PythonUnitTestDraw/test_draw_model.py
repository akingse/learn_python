import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
from math import *
from random import *


# 测试建模函数，对应
text = Text('sweep_stere')
text.size = 20
create_geometry(text)
sp = SplineCurve([Vec3(0, 0), Vec3(0, 1000, 1000), Vec3(
    0, 2000, 0), Vec3(500, 2000), Vec3(1000, 2000), ])
points = get_discrete_points_from_spline(sp, 100)
show_points_line(points)
geo = sweep_stere(Section(rotx(pi/2)*scale(50)*Arc()), Line(points), True)
create_geometry(geo)


text = Text('sweep_surround_lines')
text.size = 20
create_geometry(trans(200, 200)*text)
sp = SplineCurve(
    [Vec3(100, 0, -100), Vec3(50, 0, 0), Vec3(100, 0, 100), ])
geo = sweep_surround_lines(
    sp, rotz(pi/2)*sp, rotz(pi/2)*sp, rotz(pi)*sp, rotz(-pi/2)*sp,)
create_geometry(trans(200, 200)*geo)


# create_geometry(conus_underside_vertex(scale(100)*Arc(pi), Vec3(100, 0, 100)))
sp = SplineCurve(
    [Vec3(), Vec3(100, 0, 100), Vec3(200, 0, 0)])
sw = Sweep(Section(Vec3(), Vec3(0, 100),),
           Line(get_discrete_points_from_spline(sp, 1000)))
sw.smooth = True
create_geometry(trans(-300, 0)*sw)

create_geometry(
    trans(0, -200)*sweep_mubiu_arc(Section(Vec2(10, 10), Vec2(-10, 10), Vec2(-10, -10), Vec2(10, -10)), 100, 1/2))
show_points_line(trans(0, 200)*five_points_star(100, True))


###
text = Text('sweep_parallel')
text.size = 20
create_geometry(trans(800, 0, 0)*text)
sp = SplineCurve([Vec3(0, 0, 0), Vec3(0, 0, 1000), Vec3(
    1000, 0, 1000), Vec3(1000, 1000, 1000), Vec3(-100, 1000, 0)])
points = get_discrete_points_from_spline(sp, 100)
sec = Section(Line(Vec2(-10, -10), Vec2(10, -10), Vec2(0, 10)))
# sec = Section(Line(scale(50)*Arc()))
show_points_line(points)
geo = sweep_parallel(sec, Line(points))
create_geometry(trans(800, 0)*geo)

text = Text('sweep_curve_discrete')
text.size = 20
create_geometry(trans(-500, -500, 0)*text)
discrete_line = Line(Vec2(0, 0), Vec2(0, 1000), Vec2(
    1000, 1000), Vec2(1000, 0), Vec2(0, 0))
geo = sweep_curve_discrete(rotx(pi*0.5)*sec, discrete_line)
create_geometry(trans(-500, -500)*geo)

text = Text('sweep_spline')
text.size = 20
create_geometry(trans(1000, 0, -200)*text)
geo = sweep_spline(sec, sp)
create_geometry(trans(800+200, 0, -200) * geo)

text = Text('sweep_arc')
text.size = 20
create_geometry(trans(1000, 1000, 0)*text)
arcline1 = Line(Arc(Vec2(0, 0), Vec2(400, 400), Vec2(800, -200)))
geo = sweep_arc(rotx(pi/2)*sec, arcline1)
create_geometry(trans(1000, 1000, 0) * geo)

text = Text('sweep_surround_lines')
text.size = 20
create_geometry(trans(-1000, -1000, 0)*text)
sp = SplineCurve([Vec3(100, 0, 0), Vec3(100, 0, 100), Vec3(200, 20, 400)])
geo = sweep_surround_lines(
    sp, rotz(pi/6)*sp, rotz(pi/3)*sp, rotz(pi/2) *
    sp, rotz(pi*2/3)*sp, rotz(pi*5/6)*sp, rotz(pi)*sp,
    rotz(pi*7/6)*sp)
create_geometry(trans(-1000, -1000) * geo)

text = Text('sweep_twist')
text.size = 20
create_geometry(trans(1000, -1000, 0)*text)
geo = sweep_twist(Section(Line(scale(20)*Arc())),
                  500, 100, True, True)  # 圆形截面会变成多边形
create_geometry(trans(1000, -1000) * geo)

text = Text('sweep_guide_line')
text.size = 20
create_geometry(trans(-300, -300, 0)*text)
sec1 = Section(Vec2(0, 0), Vec2(100, 0), Vec2(50, 100))
sp1 = SplineCurve([Vec3(50, 0, 0), Vec3(20, -50, 100), Vec3(0, 50, 300)], 10)
sp2 = SplineCurve([Vec3(75, 50, 0), Vec3(20, 0, 100), Vec3(100, 0, 200)], 10)
geo = sweep_guide_line(sec1, sp1, sp2)
create_geometry(trans(-300, -300)*geo)


text = Text('loft_different_ratio')
text.size = 20
create_geometry(trans(-1000, 0, 0)*text)
sec1 = Section(Line(Vec2(0, 0), Vec2(0, 100), Vec2(100, 100), Vec2(100, 0)))
geo = loft_different_ratio(sec1, roty(pi/6) * trans(0, 0, 500)*scale(2) * sec1)
create_geometry(trans(-1000, 0)*geo)

text = Text('loft_different')
text.size = 20
create_geometry(trans(0, 1000, 0)*text)
sec2 = Section(Line(Vec2(0, 0), Vec2(0, 100), Vec2(
    50, 150), Vec2(100, 100), Vec2(100, 0)))
geo = loft_different(sec2, roty(-pi/6) * trans(0, 0, 500)*scale(2) * sec2)
create_geometry(trans(0, 1000)*geo)

text = Text('arc_correspond_point_sweep')
text.size = 20
create_geometry(trans(0, -1000, 0)*text)
arc = scale(10) * Arc(pi/4)
sec1 = Section(rotz(pi/8)*arc, rotz(pi*5/8)*arc,
               rotz(pi*9/8)*arc, rotz(pi*13/8)*arc)
sec2 = trans(0, 0, 100) * \
    Section(Vec3(20, 20, 0), Vec3(-20, 20, 0),
            Vec3(-20, -20, 0), Vec3(20, -20, 0))
geo = scale(10) * arc_correspond_point_sweep(sec1, sec2)
create_geometry(trans(0, -1000)*geo)


sp = SplineCurve(
    [Vec3(1000, 2000, 1000), Vec3(1000, 1500, 1200), Vec3(1000, 1000, 1400),
        Vec3(1000, 1000, 0), Vec3(2000, 2000, 500), Vec3(3000, 1200, 5000)]
)
show_spline_curve(sp, 20)


arc = Arc(Vec2(100, 100), Vec2(200, 50), Vec2(250, -50))
show_arc_direction(arc, 10)


points = get_discrete_points_from_spline(sp, 10)
show_points_curve_line(Line(points), 5)


secOrig = Section(Vec2(10, 0), Vec2(0, 20), Vec2(-10, 0), Vec2(0, -20))
sw = sweep_curve_discrete(secOrig, Line(
    Vec3(), Vec3(0, 0, 100), rotx(0)*scale(200)*Arc(pi)))
create_geometry(sw)
