import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

# Sweep基本体增强
# 330版本，在原单段直线的基础上，新增支持3维直线的连续sweep, sweep_stere()函数具有相同功能

# 规则
# (1) 当截面section与轨迹线line的起点重合时
# 截面保持与第一段直线的夹角theta扫掠,扫掠过程中,第一段和最后一段扫掠体保持theta夹角,其余部分将按照截面相对第一段直线矢量方向的投影进行扫掠.
# (2) 当截面section与轨迹线line的起点不重合时
# 选取截面的上的第一个点作为相对点,轨迹线line作为相对轨迹线,按照规则(1)执行扫掠.

# 注意事项
# (1) 暂不支持曲线类型的混合sweep，可以将曲线离散，但是注意交点处的衔接;
# (2) 注意每段直线段的长度,长短过短可能导致截面自相交(可以绘制但几何错误);


# 630版本

# 例子1
sec = trans(0, 0, 0)*roty(pi/2)*Section(Vec2(100, -100),
                                        Vec3(0, 100), Vec2(-100, -100))
line = Line(Vec3(0, 0, 0), Vec3(300, 0, 0), Vec3(
    800, 300, 0), Vec3(900, 0, 300), Vec3(1500, 0, 0))
sw0 = Sweep(sec, line)
# sw = Swept(sec, line)
# create_geometry(sw)

# simple1
sec = Section(Vec2(100, -100), Vec2(0, 100), Vec2(-100, -100))
line = Line(Vec3(0, 0, 0), Vec3(0, 0, 300))
sw1 = Sweep(sec, line)
# create_geometry(Combine(sw0, sw1))
# create_geometry(sw0 - sw1)
# create_geometry(sw0 + sw1)


# 例子2
sec = trans(0, 50, 100)*scale(50)*roty(pi/2)*Section(Arc())
line = Line(Vec3(0, 0, 0), Vec3(300, 300, 0), Vec3(
    800, -300, 0), Vec3(1000, 0, 0), Vec3(1200, 0, -100))
# sw = Sweep(sec, line)
# sw = Swept(sec, line)
# create_geometry(trans(0, 1000)*sw)

# sweep 布尔bug

Section1 = Section(scale(100/2)*Arc(2*pi))
Section2 = Section(scale(50/2)*Arc(2*pi))
Line1 = Line(Vec3(0, 0, 0), Vec3(0, 0, 100))
Sweep1 = rotate(Vec3(0, 1, 0), pi/2)*Sweep(Section1-Section2, Line1)  #

Section3 = Section(scale(100/2)*Arc(2*pi))
Line2 = Line(Vec3(0, 0, 0), Vec3(0, 0, 100))
Sweep2 = translate(
    Vec3(0, 0, -100/2))*Sweep(Section3, Line2)
# Sweep3 = translate(Vec3(200, 0, 0))*Sweep2
create_geometry(Sweep1)
create_geometry(Sweep2)
# create_geometry(Sweep1-Sweep2)
# create_geometry(Sweep2-Sweep1)
