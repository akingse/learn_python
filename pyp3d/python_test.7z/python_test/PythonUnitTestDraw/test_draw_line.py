import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用

'''
Line测试
6横线，4拱线
3斜线

'''
# ----------------------------------------------------------------------------

# 功能测试
text1 = Text('Line()').color(1, 1, 1, 1)
text1.size = 20
# create_geometry(text1)
line = scale(100)*Line()  # 默认不显示
# create_geometry(line)

a = Vec3(0, 0, 0)
b = Vec3(2, 0, 0)
c = Vec2(0, -1/2)
d = Vec2(2, -1/2)
l1 = [a, b]
t1 = (a, b)
l2 = [c, d]
t2 = (c, d)

text2 = Text('Line(*)')
text2.size = 20
create_geometry(trans(0, 150, 0)*text2)
create_geometry(trans(0, 150, 0)*scale(100)*Line(*l1))
create_geometry(trans(0, 150, 0)*scale(100)*Line(*l2))

text2 = Text('Line(list)')
text2.size = 20
create_geometry(trans(200, 0, 0)*text2)
create_geometry(trans(200, 0, 0)*scale(100)*Line(l1))
create_geometry(trans(200, 0, 0)*scale(100)*Line(l2))

text2 = Text('Line(tuple)')
text2.size = 20
create_geometry(trans(200, 150, 0)*text2)
create_geometry(trans(200, 150, 0)*scale(100)*Line(t1).color(0, 0.5, 0.5, 1))
create_geometry(trans(200, 150, 0)*scale(100)*Line(t2).color(0, 0.5, 0.5, 1))


# Arc()
l3 = [Vec2(-1, -1), Vec2(1, -1), Arc(pi)]
l4 = [Vec3(-1, -1, 1), Vec3(1, -1, 1), Arc(pi)]  # 自动连接，但不闭合
create_geometry(trans(0, -200, 0)*scale(100)*Line(l3))
create_geometry(trans(0, -400, 0)*scale(100)*Line(l4))

# append方法
ln1 = Line()
ln2 = Line()
for i in l3:
    ln1.append(i)
for i in l4:
    ln2.append(i)
create_geometry(trans(300, -200, 0)*scale(100)*ln1)
create_geometry(trans(300, -400, 0)*scale(100)*ln2)


# ----------------------------------------------------------------------------
# 矩阵测试
# compound matrix

text3 = Text('trans-rot')
text3.size = 20
create_geometry(trans(600, 600, 0)*text3)
line1 = trans(800, 0, 0)*scale(100)*Line(*l1)
# rotate 旋转平移矩阵
T = arbitrary_rotate(Vec3(0, 0, 0), Vec3(0, 0, 1), pi/4)
create_geometry(T*line1.color(0, 0.5, 0.5, 1))

# shear 错切矩阵
text4 = Text('shear line')
text4.size = 20
create_geometry(trans(1000, 0, 0)*text4)
line2 = scale(100)*Line(*l1)
T = trans(1000, 0, 0)*shearx(y=1, z=1)
create_geometry(T*line2)

# reflect 镜像矩阵
text5 = Text('reflect line')
text5.size = 20
create_geometry(trans(-1000, 0, 0)*text5)
T = mirror(g_matrixE, 'XoZ')*mirror()
create_geometry(T*line1.color(0, 0.5, 0.5, 1))

# while True:
#     sys.exit(0)


# 基本体类型

# 测试segment类
seg = Segment(Vec2(0, 0), Vec2(20, 10))
# seg = Segment(Vec2(), Vec2())
seg = trans(1)*seg
seg = scale(10)*seg
create_geometry(seg)
p0 = seg[0]
p1 = seg[1]
n = seg.norm
v = seg.vector
# print(p1)
# print(p0)
# print(v)
# print(seg.start)
# print(seg.end)
# print(seg.list)
# print(seg.vectorU)
# print(seg.m_end)
# print(seg.m_start)
text = Text('seg')
text.size = 20
create_geometry(trans(-500, 0, 0)*text)
create_geometry(trans(-500, 0, 0)*Line(seg.list))

# 新版BIMBase可绘制
seg = Segment(Vec3(0, 0, 100), Vec2(50, 50))
create_geometry(seg)

points = get_discrete_points_from_segment(seg)
create_geometry(Line(points))

# segment矩阵测试
text = Text('trans-rot-seg')
text.size = 20
create_geometry(trans(-800, 800, 0)*text)
# rotate 旋转平移矩阵
T = arbitrary_rotate(Vec3(0, 0, 0), Vec3(0, 0, 1), pi/2)
create_geometry(trans(-800, 800, 0)*(T*Line(seg.list).color(0, 0.5, 0.5, 1)))

# shear 错切矩阵
text = Text('shear seg')
text.size = 20
create_geometry(trans(800, -800, 0)*text)
T = trans(800, -800, 0)*shearx(y=1, z=1)
create_geometry(T*Line(seg.list))

# reflect 反射矩阵
text = Text('reflect seg')
text.size = 20
create_geometry(trans(0, -800, 0)*text)
T = mirror(g_matrixE, 'XoZ')*mirror()
create_geometry(trans(0, -800, 0)*T*Line(seg.list).color(0, 0.5, 0.5, 1))


# 测试spline曲线
pList = [Vec2(0, 0), Vec2(100, 300), Vec2(200, 0), Vec2(
    100, -100), Vec2(0, 0)]  # ,Vec2(300,200),Vec2(400,0)]
pList = [Vec3(0, 0, 0), Vec3(0, 100, 300), Vec3(0, 200, 0),
         Vec3(300, 200, 0), Vec3(0, 0, 0)]  # ,Vec3(0,100,300),]
# pList=[Vec2(0,0),Vec2(100,300),Vec2(300,0)]
pList = [Vec3(0, 0), Vec3(1000, 300), Vec3(3000, 0)]

sl = SplineCurve(pList, 5, 2)
# create_geometry(sl.color(0,1,1))
# create_geometry(Line(scale(100)*Arc(pi)).color(0,1,1))
# create_geometry(Line(sl).color(0,0,0))

points = get_discrete_points_from_spline(SplineCurve(pList), 4)
# show_spline_curve(SplineCurve(pList))
# create_geometry(trans(0, -50)*Line(points))

sp = SplineCurve([Vec2(0, 0), Vec3(500, 200, 500), Vec3(800, 500, 300), Vec3(900, 900, 500),
                  Vec3(1200, 0, 900), Vec3(900, -600, 400), Vec3(-1000, -400, 500), Vec3(-800, 700, 800)])
# show_spline_curve(sp)

# spline曲线矩阵测试
text = Text('trans-rot-spline')
text.size = 20
create_geometry(trans(800, 800, 0)*text)
# rotate 旋转平移矩阵
T = arbitrary_rotate(Vec3(0, 0, 0), Vec3(1, 0, 0), pi/4)
create_geometry(trans(800, 800, 0)*(T*sp.color(0, 0.5, 0.5, 1)))

# shear 错切矩阵
text = Text('shear spline')
text.size = 20
create_geometry(trans(1000, 1000, 0)*text)
T = shearx(y=1, z=1)
create_geometry(trans(1000, 1000, 0)*(T*sp))

# # reflect 反射矩阵
text = Text('reflect spline')
text.size = 20
create_geometry(trans(-1000, -1000, 0)*text)
T = mirror(g_matrixE, 'XoZ')*mirror()
create_geometry(trans(-1000, -1000, 0)*(T*sp.color(0, 0.5, 0.5, 1)))
