import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *

sweep_stere
sweep_spline
sweep_arc

# sweep样条线
sec = rotz(pi/2)*rotx(pi/2)*scale(5)*Section(Vec2(20, -20),
                                             Vec2(20, 10), Vec2(-10, 0), )
sp = SplineCurve([Vec3(0, 0), Vec3(500, -500), Vec3(1000, 500), Vec3(2000, 0)])
geo = sweep_spline(sec, sp)
# create_geometry(sp.colorBlue())
# create_geometry(geo.colorCyan())


# sweep Arc
# 缩放规则不同
# sec = Section(trans(200)*scale(30)*rotx(pi/2)*Arc())
# arc = scale(200, 150)*Arc(-pi)
# geo = sweep_arc(sec, Line(arc))
# create_geometry(arc.colorBlue())
# create_geometry(geo)


# sec2 = Section(trans(500)*scale(30)*rotx(pi/2)*Arc())
# arc2 = scale(200, 150)*Arc(pi)
# geo2 = sweep_arc(sec2, Line(arc2))
# create_geometry(arc2.colorBlue())
# create_geometry(geo2)

# create_geometry(sec.colorRed())
sec2 = trans(30, 30)*rotz(-pi/6)*sec
create_geometry(Loft(sec, sec2).colorBlue())
