import sys
import os
import time
sys.path.append(os.path.join(os.path.dirname(__file__), '..//'))
from pyp3d import *

line = Line(Vec3(), Line(Vec3(-10, 10), Vec3(10, 10)), scale(50)*Arc(pi))
res = get_nested_parts_from_line(line)
create_geometry(line)
show_points_curve_line(Line(res))
# print(res)
res = get_nested_parts_from_section(Section(line))
create_geometry(Section(line))
show_points_curve_line(Line(res))
res = get_fragments_from_line(line)
print_result(len(res) == 4)
# extract
point = get_first_point_on_line(line)
print_result(is_coincident(point, Vec3()))
point = get_first_point_on_section(Section(line))
print_result(is_coincident(point, Vec3()))

mat = get_first_matrix_from_line(line)  # default is 2D
# print_matrix(mat)
print_result(is_identify_matrix(mat))
mat = get_matrix_from_section(Section(line))
# print_matrix(mat)
print_result(is_identify_matrix(mat))

point = [Vec3(), Vec3(-10, 10), Vec3(10, 10),
         Vec3(10, 10), Vec3(-10, -10)]
res = get_segments_from_points(point)
res = get_points_from_segments(trans(0, 0, 20)*res)
# print(point)
# print(res)
show_points_line(point)
show_points_line(res)
