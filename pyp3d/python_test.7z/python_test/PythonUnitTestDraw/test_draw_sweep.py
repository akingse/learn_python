import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..\\'))
from pyp3d import *
# 测试用例程序，仅供测试使用
'''
与loft基本一致
6+5=11个模型
'''

# Sweep函数实现更换为SweptBody
# ----------------------------------------------------------------------------
# 功能测试
# Sweep = Swept
text1 = Text('Sweep()').color(1, 1, 1, 1)
text1.size = 20
create_geometry(trans(100, 0, 0)*text1)
section_0 = translation(200, 0, 0) * rotate(g_axisX, 0.5*pi) * \
    Section(Vec2(0, 0), Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section_1 = translation(200, 0, 0) * rotate(g_axisX, 0.5*pi) * \
    Section(Vec2(80, 80), Vec2(60, 80), Vec2(60, 60), Vec2(80, 60))
section_2 = translation(200, 0, 0) * rotate(g_axisX, 0.5*pi) * \
    Section(Vec2(50, 50), Vec2(20, 50), Vec2(20, 20), Vec2(50, 20))
# section_2 = translation(200,0,0) * rotate(axisX, 0.5*pi) * Section(Vec2(50,50), Vec2(20,50), Vec2(-20,-20), Vec2(50,20))

# create_geometry(section_0 - section_1 - section_2)
linearc = Line(scale(500) * Arc(0.5*pi))
sweep = Sweep(section_0 - section_1 - section_2, linearc)
create_geometry(sweep)
lineln = Line(Vec3(0, 0, 0), Vec3(0, 100, 0))
sweep = Sweep(section_0 - section_1 - section_2, lineln)
create_geometry(translation(-200, 0, 0)*sweep)
# exit()

text = Text('to_section').color(1, 1, 1, 1)
text.size = 20
create_geometry(trans(-100, 0, 0)*text)
section0 = to_section(
    Vec3(0, 0, 0),
    Vec3(1, 0, 0),
    Vec3(1, 1, 1),)
line = Line(Vec3(0, 0, 0), Vec3(0, 0, 1))
create_geometry(trans(-200, 0, 0)*scale(100)*Sweep(section0, line))


# 布尔运算（line-sweep）
line = Line(Vec3(0, 0, 0), Vec3(0, 0, 1))
section1 = Section(
    Vec2(0, 0),
    Vec2(1, 0),
    Vec2(1, 1),
    Vec2(0, 1))

section2 = trans(0, -0.5, 0)*Section(
    Vec2(0, 0),
    Vec2(2, 0),
    Vec2(2, 1),
    Vec2(0, 1))

section3 = Section(Arc())
section = section1 + section2 + section3  # v
# section=section1 + section2   #v
# section=section1 - section2   #v
# section=section2 - section1   #v
# section=section1 + section3   #v
# section=section1 - section3   #v
# section=section3 - section1   #v
# section=section2 + section3   #v
# section=section2 - section3   #
sweep = trans(500, 0, 0)*scale(100)*Sweep(section, line)
create_geometry(sweep)

# section=section1 - section2 - section3 #v
# section=section2 - section1 + section3 #
# section=section1 - section2 + section3 #
section = section1 + section3 - section2
sweep = trans(1000, 0, 0)*scale(100)*Sweep(section, line)
create_geometry(sweep)


# XY面
# section_0 = Section(Vec2(0,0), Vec2(100,0), Vec2(100,100), Vec2(0,100))
# section_1 = Section(Vec2(80,80), Vec2(60,80), Vec2(60,60), Vec2(80,60))
# section_2 = Section(Vec2(50,50), Vec2(20,50), Vec2(20,20), Vec2(50,20))
# line = Line(Vec3(0,0,0),Vec3(0,0,200))
# YZ面
section_0 = rotate(g_axisY, 0.5*pi) * Section(Vec2(0, 0),
                                              Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section_1 = rotate(g_axisY, 0.5*pi) * Section(Vec2(80, 80),
                                              Vec2(60, 80), Vec2(60, 60), Vec2(80, 60))
section_2 = rotate(g_axisY, 0.5*pi) * Section(Vec2(50, 50),
                                              Vec2(20, 50), Vec2(20, 20), Vec2(50, 20))
line = Line(Vec3(0, 0, 0), Vec3(100, 0, 0))
sweep = trans(0, -200, 0)*scale(1)*Sweep(section_0-section_1-section_2, line)
create_geometry(sweep)

# XZ面 arc
section_0 = translation(100, 0, 0) * rotate(g_axisX, -0.5*pi) * \
    Section(Vec2(0, 0), Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section_1 = translation(100, 0, 0) * rotate(g_axisX, -0.5*pi) * \
    Section(Vec2(80, 80), Vec2(60, 80), Vec2(60, 60), Vec2(80, 60))
section_2 = translation(100, 0, 0) * rotate(g_axisX, -0.5*pi) * \
    Section(Vec2(50, 50), Vec2(20, 50), Vec2(20, 20), Vec2(50, 20))
line = Line(Arc(0.5*pi))
sweep = trans(0, -400, 0)*scale(1)*Sweep(section_0-section_1-section_2, line)
create_geometry(sweep)

# XZ面 line
section_0 = rotate(Vec3(1, 0, 0), 0.5*pi) * Section(Vec2(0, 0),
                                                    Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section_1 = rotate(Vec3(1, 0, 0), 0.5*pi) * Section(Vec2(80,
                                                         80), Vec2(60, 80), Vec2(60, 60), Vec2(80, 60))
section_2 = rotate(Vec3(1, 0, 0), 0.5*pi) * Section(Vec2(50, 50),
                                                    Vec2(20, 50), Vec2(-20, -20), Vec2(50, 20))
line = Line(Vec3(0, 0, 0), Vec3(0, 100, 0))
sweep = trans(0, -600, 0)*scale(1)*Sweep(section_0-section_1-section_2, line)
create_geometry(sweep)


# 矩阵作用
lineZ = Line(Vec3(0, 0, 0), Vec3(0, 0, 100))
lineY = Line(Vec3(0, 0, 0), Vec3(0, 100, 0))
lineX = Line(Vec3(0, 0, 0), Vec3(100, 0, 0))

section1 = Section(Vec2(0, 0), Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))
section2 = Section(Vec2(0, 0), Vec2(100, 0), Vec2(100, 100), Vec2(0, 100))

sweep1 = Sweep(trans(-50, -50)*section1-scale(0.4)
               * section2, lineZ)  # 面（布尔前） 矩阵
create_geometry(trans(0, 400, 0)*sweep1)
sweep2 = Sweep(roty(-pi/2)*(trans(-50, -50) *
               section1+section2), lineX)  # 面（布尔后） 矩阵
create_geometry(trans(0, 600, 0)*sweep2)
sweep3 = scale(2)*Sweep(rotx(pi/2)*section1, lineY)  # 体 矩阵
create_geometry(trans(0, 800, 0)*sweep3)


# 新增(swept)基本体
# test1
section = Section(Vec3(10, 0, 0), Vec3(10, -10, 0),
                  Vec3(-10, 10, 0), Vec3(0, 10, 0), Ellipse(Vec3(10, 10, 0), Vec3(-10, 0, 0), Vec3(0, -10, 0), 0, pi/2))
line = Line(Vec3(0, 0), Vec3(0, 0, 100), Vec3(
    100, 0, 100), Vec3(100, 100, 100),)  #
sweep = Sweep(section, line).colorBlue()
swept = Swept(section, line).colorGreen()
sweeppy = sweep_stere(section, line).colorRed()
create_geometry(trans(-1000, 100)*sweep)
create_geometry(trans(-1000, 200)*swept)
create_geometry(trans(-1000, 0)*sweeppy)

# test2
section = Section(Vec3(15, 5, 0), Vec3(5, 5, 0),
                  Vec3(5, 15, 0), Vec3(-5, 15, 0), Vec3(-5, 5, 0),
                  Vec3(-15, 5, 0), Vec3(-15, -5, 0), Vec3(-5, -5, 0),
                  Vec3(-5, -15, 0), Vec3(5, -15, 0), Vec3(5, -5, 0),
                  Vec3(15, -5, 0), )  # Vec3(15, 5, 0)
line = Line(Ellipse(Vec3(100, 0, 0), Vec3(-100, 0, 0),
            Vec3(0, 0, 50), 0, 2*pi))  #
swept = Swept(section, line).colorGreen()
create_geometry(trans(-800, 200)*swept)

# test3
sectionOut = Section(Vec3(20, 20, 0),
                     Vec3(-20, 20, 0), Vec3(-20, -20, 0), Vec3(20, -20, 0), Vec3(20, 20, 0))
sectionIn = Section(Vec3(15, 5, 0),
                    Vec3(15, -5, 0), Vec3(5, -5, 0), Vec3(5, -15, 0),
                    Vec3(-5, -15, 0), Vec3(-5, -5, 0), Vec3(-15, -5, 0),
                    Vec3(-15, 5, 0), Vec3(-5, 5, 0), Vec3(-5, 15, 0),
                    Vec3(5, 15, 0), Vec3(5, 5, 0), Vec3(15, 5, 0))  # rot the section error
section = sectionOut-sectionIn
line = Line(Segment(Vec3(0, 0), Vec3(0, 0, 100)), Ellipse(Vec3(50, 0, 100), Vec3(-50, 0, 0), Vec3(0, 0, 50), 0, pi),
            Segment(Vec3(100, 0, 100), Vec3(100, 0)), Ellipse(Vec3(150, 0, 0), Vec3(-50, 0, 0), Vec3(0, 0, -50), 0, pi))
swept = Swept(section, line).colorGreen()
create_geometry(trans(-800, -200)*swept)


while True:
    sys.exit(0)
