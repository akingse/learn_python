import sys
import os
sys.path.append(os.path.join(os.path.dirname(__file__), '..//'))
from pyp3d import *

# ------------------------------------------------------------------------------------------
# POINT
# 判断点在直线上
point_1 = Vec3(1, 1, 0)
segment_1 = Segment(Vec2(-10, -10), Vec2(10, 10))
res = is_point_on_line(point_1, segment_1, True)
print_result(res)

# 判断点与线段的关系
point_2 = Vec3(5, 1, 1)
segment_2 = Segment(Vec2(-10, -10), Vec2(10, 10))
res = is_point_on_segment(point_2, segment_2) == 'POINT_OUT'
print_result(res)

# 点到直线的距离
point_3 = Vec3(0, 3, 4)
segment_3 = Segment(Vec2(-10, 0), Vec2(10, 0))
res = is_float_equal(get_distance_of_point_line(point_3, segment_3), 5)
print_result(res)

# 获取点距公式中的点
point_4 = Vec3(2, 3, 4)
point4 = Vec3(2, 0, 0)
segment_4 = Segment(Vec2(-10, 0), Vec2(10, 0))
res = get_nearest_point_of_point_line(point_4, segment_4)
print_result(is_coincident(res, point4))

# 判断点与圆弧的关系
point_5 = Vec3(50, 0, 0)
arc_1 = scale(50)*Arc()
res = is_point_on_arc(point_5, arc_1) == 'POINT_ON'
print_result(res)

# ------------------------------------------------------------------------------------------
# LINE
# 直线（线段）与直线（线段）的关系
line_1 = Segment(Vec3(0, 0), Vec3(60098.1, 29586.95), )
line_2 = Segment(Vec3(60098.1, 29586.95), Vec3(-213.5, 57773.33), )
res = is_two_line_intersect(line_1, line_2) == 'INTERSECT_V'
print_result(res)

# 两条线段分离的快速算法
line_3 = Segment(Vec3(0, -10), Vec3(300, 100))
line_4 = Segment(Vec3(200, 0), Vec3(100, 200))
res = is_two_segments_intersect_2D(line_3, line_4)
print_result(res)

# 空间（异面）直线间的距离
line_5 = Segment(Vec3(-200, 10, 0), Vec3(200, 10, 0))
line_6 = Segment(Vec3(0, -500, 400), Vec3(0, 500, 400))
res = get_distance_of_two_lines(line_5, line_6)
print_result(res == 400)

# 平面中直线夹角
theta = get_angle_of_two_segments(
    [Vec2(), Vec2(200, 0)], [Vec2(), Vec2(200, 200)])
print_result(is_float_equal(theta, pi/4))

# 获取两直线交点的列表
res = get_intersect_point_of_two_lines(
    Segment(Vec3(0, 0), Vec3(1, 0)), Segment(Vec3(1, 0), Vec3(10, 0)), False, False)
print_result(is_coincident(res[0], Vec3(1, 0, 0)))

# ARC
# 直线（线段）与圆弧的关系
line_7 = Segment(Vec3(0, 0), Vec3(50, 100))
arc_2 = scale(50)*Arc()
res = is_line_arc_intersect(line_7, arc_2)
print_result(res == 'LINE_ARC_INTER')

# 获取直线和圆弧的交点
# list_2 = [Vec3(50, 50)]
line_8 = Segment(Vec3(0, 0), Vec3(100, 100))
arc_3 = scale(50*sqrt(2))*Arc()
res = get_intersect_point_of_line_arc(line_8, arc_3)
print_result(is_coincident(res[0], Vec3(50, 50)))

# 两个圆弧之间的关系
arc_4 = scale(50)*Arc()
arc_5 = trans(80)*scale(50)*Arc()
res = is_two_arcs_intersect(arc_4, arc_5)
print_result(res == 'ARCS_INTER')

# 椭圆与椭圆交点
arc_6 = arc_of_oval_angle(20, 10, 0, 2*pi, True, True)
arc_7 = arc_of_oval_angle(10, 20, 0, 2*pi, True, True)
create_geometry(arc_6)
create_geometry(arc_7)
res = get_intersect_point_of_two_arcs(arc_6, arc_7)
print_result(is_coincident(res[1], Vec3(-8.944271909999157, -8.94427190999916, 0))
             and is_coincident(res[2], Vec3(8.944271909999157, 8.94427190999916, 0))
             and is_coincident(res[3], Vec3(8.944271909999157, -8.94427190999916, 0))
             and is_coincident(res[0], Vec3(-8.944271909999157, 8.94427190999916, 0)))

# SPLINE
# 直线与样条线的交点
points1 = [Vec3(-20, -5, 0), Vec3(0, 0, 0), Vec3(100, 100, 0)]
curve_1 = SplineCurve(points1)
createGeometry(curve_1)
line_9 = Segment(Vec3(-0, 50), Vec3(0, -50))
res = get_intersect_point_of_line_spline(line_9, curve_1)
print_result(is_coincident(res[0], Vec3(0.0, 7.196969696969688, 0.0)))

# 圆弧与样条线的交点
arc_8 = scale(50)*Arc()
points2 = [Vec3(-20, -5, 0), Vec3(0, 0, 0), Vec3(100, 100, 0)]
curve_2 = SplineCurve(points2)
createGeometry(curve_2)
createGeometry(arc_8)
res = get_intersect_point_of_arc_spline(arc_8, curve_2)
print_result(is_coincident(res[0], Vec3(
    34.19089188252538, 36.482638504876, 0.0)))

# 样条线与样条线的交点
points3 = [Vec3(-20, -5, 0), Vec3(0, 0, 0), Vec3(100, 100, 0)]
curve_3 = SplineCurve(points3)
createGeometry(curve_3)
points4 = [Vec3(0, 50, 0), Vec3(20, 0, 0), Vec3(50, -100, 0)]
curve_4 = SplineCurve(points4)
createGeometry(curve_4)
res = get_intersect_point_of_two_splines(curve_3, curve_4)
print_result(is_coincident(res[0], Vec3(
    12.309298377799363, 17.163645276373245, 0.0)))

# ------------------------------------------------------------------------------------------
# PLANE
# 两个正交矩阵的关系
plane_1 = GeTransform([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]])
plane_2 = GeTransform([[1, 0, 0, 0], [0, 7, 0, 0], [0, 0, 1, 0]])
res = is_two_planes_intersect(plane_1, plane_2)
print_result(res == 'PLANES_COPLANAR')

# (平行)平面间的距离
plane_3 = rotx(pi/4)
plane_4 = rotx(pi/4)*trans(1, 1, -1)
res = get_distance_of_two_planes(plane_3, plane_4)
print_result(is_float_equal(res, 1))

# 平面之间的夹角
plane_5 = GeTransform([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]])
plane_6 = rotx(pi/4)
res = get_angle_of_two_planes(plane_5, plane_6)
print_result(is_float_equal(res, 3/4*pi))

# 两平面的交线
plane_7 = GeTransform([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]])
plane_8 = rotx(pi/4)
res = get_intersect_line_of_two_planes(plane_7, plane_8)
# line = show_extend_line(Segment(res[0], res[1]))

# 直线（线段）与平面的关系
line_10 = Segment(Vec3(0, 0, 0), Vec3(10, 0, 0))
plane_9 = get_matrix_from_three_points(
    [Vec3(0, 0, 0), Vec3(50, 0, 0), Vec3(0, 50, 50)])
res = is_line_locate_on_plane(line_10, plane_9)
print_result(res == 'LINE_ON')

# 直线（线段）与平面的交点
plane_10 = rotx(pi/4)
line_10 = Segment(Vec3(0, 1, -1), Vec3(0, -1, 1))
res = get_intersect_point_of_line_plane(line_10, plane_10)
print_result(is_coincident(res[0], Vec3(0.0, 0.0, 0.0)))

# 圆弧与平面的关系
plane_11 = GeTransform([[1, 0, 0, 0], [0, 1, 0, 0], [0, 0, 1, 0]])
arc_9 = scale(50)*Arc()
res = is_arc_locate_on_plane(arc_9, plane_11)
print_result(res == 'ARC_COPLANAR')

# 圆弧与平面的交点
plane_11 = get_matrix_from_three_points(
    [Vec3(0, -10, 0), Vec3(0, 10, 0), Vec3(10, 0, 10)])
show_coordinate_plane(plane_11)
arc_10 = scale(50)*Arc(3/4*pi)
createGeometry(arc_10)
res = get_intersect_point_of_arc_plane(arc_10, plane_11)
print_result(is_coincident(res[0], Vec3(0.0, 50.0, 0.0)))

# 样条线与平面的关系
plane_12 = GeTransform = g_matrixE
points4 = [Vec3(-20, -5, 0), Vec3(0, 0, 0), Vec3(100, 100, 0)]
curve_4 = SplineCurve(points4)
res = is_spline_locate_on_plane(curve_4, plane_12)
print_result(res == 'SPLINE_ON')

# 样条线与平面的交点
plane_13 = g_matrixE
show_coordinate_plane(plane_13)
points5 = [Vec3(-0, 0, 0), Vec3(30, 0, 30), Vec3(60, 0, -30)]
curve_5 = SplineCurve(points5)
createGeometry(curve_5)
res = get_intersect_point_of_spline_plane(curve_5, plane_13)
print_result(is_coincident(res[1], Vec3(40.0, 0.0, 0.0)))

# 两个fragments的交点
line_11 = Segment(Vec3(-20, 0), Vec3(20, 0))
line_12 = Segment(Vec3(0, 20), Vec3(0, -20))
res = get_intersect_points_of_fragments(line_11, line_12)
print_result(is_coincident(res[0], Vec3(0.0, 0.0, 0.0)))

# ------------------------------------------------------------------------------------------
# POLYGON
# 判断点是否在多边形上
point_a = Vec3(10, 10, 0)
polygon_1 = [Vec3(0, 0), Vec3(100, 0), Vec3(
    100, 100), Vec3(0, 100), Vec3(0, 0)]
res = is_point_on_polygon(point_a, polygon_1) == False
print_result(res)

# 判断点是否在多边形内
point_b = Vec3(10, 10, 0)
polygon_2 = [Vec3(0, 0), Vec3(100, 0), Vec3(
    100, 100), Vec3(0, 100), Vec3(0, 0)]
res = is_point_in_polygon(point_b, polygon_2) == True
print_result(res)

# 点是否在轮廓线上
point_c = Vec3(10, 10, 0)
sec_1 = Section(Vec2(0, 0), Vec2(10, 0), Vec2(10, 10), Vec2(0, 10))
res = is_point_on_contourline(point_c, sec_1)
print_result(res)

# 点在截面内（或截面轮廓线上）
point_d = Vec3(5, 5, 0)
sec_2 = Section(Vec2(0, 0), Vec2(10, 0), Vec2(10, 10), Vec2(0, 10))
res = is_point_in_contourline(point_d, sec_2)
print_result(res)

# 多边形是否自相交
polygon_3 = [Vec3(0, 0), Vec3(100, 0), Vec3(
    100, 100), Vec3(0, 100), Vec3(0, 0)]
res = is_polygon_self_intersect(polygon_3) == False
print_result(res)

# 轮廓线是否自相交
line_a = Line(Vec3(0, 0), Vec3(100, 0), Vec3(50, 100), Vec3(50, -100))
res = is_contourline_self_intersect(line_a) == 'NOT_COPLANAR'
print_result(res)

# 判断两个截面是否有相交的部分
sec_3 = Section(Vec2(0, 0), Vec2(10, 0), Vec2(10, 10), Vec2(0, 10))
sec_4 = trans(30, 0, 0)*Section(Vec2(0, 0),
                                Vec2(10, 0), Vec2(10, 10), Vec2(0, 10))
res = is_two_sections_intersect(sec_3, sec_4) == 'COPLANAR_SEPA'
print_result(res)

# ------------------------------------------------------------------------------------------
# DIMENSION
# 判断Line是否闭合
line_b = Line(Vec2(0, 0), Vec2(20, 0), Vec2(20, 20), Vec2(40, 20))
res = is_line_close(line_b) == False
print_result(res)

# 判断Line在XoY二维平面
line_c = Line(Vec3(0, 0), Vec3(50, 0))
res = is_line_in_two_dimensional(line_c)
print_result(res)

# 参数是否全部在同一个平面上（支持多种类型）
line_d = Line(Vec3(0, 0), Vec3(50, 0))
plane_14 = g_matrixE
res = is_parts_locate_on_plane(line_d, plane_14)
print_result(res)

# 线（参数）共面
line_e = Line(Vec3(0, 0), Vec3(20, 0), Vec3(20, 20))
res = is_line_on_same_plane(line_e)
print_result(res)

# 获取Line的类型
line_f = Line(Vec3(0, 0), Vec3(20, 0), Vec3(20, 20))
create_geometry(line_f.color(0, 0.5, 0.5, 1))
res = get_line_dimensional_type(line_f) == 'LINE_XOY'
print_result(res)

# ------------------------------------------------------------------------------------------
# CALCULATE
# 二维圆弧的包围盒
arc_11 = scale(50)*Arc(pi)
res = get_range_of_arc_2D(arc_11, False)
print_result(res)

# 二维平面包围盒范围（仅点和圆弧）
sec_5 = Section(Vec2(0, -50), Vec2(150, -50), trans(150, 0) *
                scale(50)*rotate(Vec3(0, 0, -1), pi/2)*Arc(pi), Vec2(0, 50))
res = get_range_of_section_2D(sec_5, False)
print_result(res)


# 点到直线的距离
distance = get_distance_of_point_line(
    Vec3(-1, 1, 0), Segment(Vec2(0, -1), Vec2(5, 0)))
# distance0=get_distance_of_point_line0(Vec3(-1,1,2),[Vec2(0,-1),Vec2(5,0)])
rela = is_two_planes_intersect(rotx(pi/3), rotx(pi/3)*trans(1, 2, 3))


# pts = get_intersect_point_of_two_lines(
#     Segment(Vec3(-38, 0), Vec3(-39, 0)), Segment(Vec3(0, 38), Vec3(0, 39)), True, True)
pts = get_intersect_point_of_two_lines(
    Segment(Vec3(0, 0), Vec3(1, 0)), Segment(Vec3(1, 0), Vec3(10, 0)), False, False)


re1 = is_two_line_intersect(
    Segment(Vec3(0, 0), Vec3(1e11, 1e11)), Segment(Vec3(0, 0), Vec3(-1e11, -1e11)), True, True)


# 整体右乘
arc = roty(pi/2)*scale(100)*Section(Arc())
arc = rotz(pi/4)*scale(100)*Arc(pi)
# arc.rmul(transz(1))
# create_geometry(arc)
res = get_range_of_arc_2D(arc, True)
# show_points_line([res[4], res[5], res[6], res[7]])


# 点与圆弧
p = Vec3(0, 10)
arc = scale(20, 10)*Arc()
arc2 = trans(5, 5)*rotz(pi/6)*scale(10, 20)*Arc()
# create_geometry(arc)
# create_geometry(arc2)
# line=[Vec3(-20,-10,0),Vec3(20,10,0)]
# line=[Vec3(-10,-10,0),Vec3(10,-10,0)] #水平
line = Segment(Vec3(-10, -10, 0), Vec3(10, -10, 0))  # 竖直
create_geometry(Line(Vec2(5, -30), Vec2(5, 30)))
mat_std = arc.transformation  # 将arc1单位化
# create_geometry(inverse(mat_std)*arc2)

# diag=rectangle_diagonal_section(Vec2(0,0),Vec2(20,10))
# create_geometry(shear('y',x=1)*diag)

# create_geometry(shear('y',x=1)*arc) #错切
# create_geometry(rotz(pi/12)*arc)
# create_geometry(show_points_line(line))
mat = arc.transformation
invM = inverse(mat)
arc2n = invM*arc2
# create_geometry(invM*arc2)
p0 = invM*to_vec3(line.start)
p1 = invM*to_vec3(line.end)
# create_geometry(show_points_line([p0,p1]))
bl = is_point_on_arc(p, arc)
# show_points_line(line.list)
# create_geometry(arc2)
roots = get_intersect_point_of_line_arc(line, arc2, True, True)


p1 = roots[0]
p2 = roots[1]
create_geometry(show_points_line([p1, p2]))
x = get_intersect_point_of_two_arcs(arc, arc2)
create_geometry(show_points_line(x))

relation = is_two_line_intersect(
    Segment(Vec3(0, 0), Vec3(10, 0)), Segment(Vec3(2, 2), Vec3(10, 2)))

bl = is_point_on_arc(p1, arc)
bl = is_point_on_arc(p2, arc)

bl = is_point_on_arc(Vec3(0, 0, 0), arc)
bl = is_point_on_arc(Vec3(100, 0, 0), arc)
print_result(bl == 'POINT_OUT')


# arc1=scale(300,200)*Arc()
arc1 = trans(100)*rotz(-pi/6)*scale(200, 200)*Arc()
arc2 = trans(50)*rotz(0)*scale(200, 200)*Arc()
# create_geometry(arc1)
# create_geometry(arc2)
points = get_intersect_point_of_two_arcs(arc1, arc2)
# show_points_line(points)
# show_arcs_and_axis(arc2)


arc1 = trans(3, 2)*scale(5)*Arc()
arc2 = trans(3, 2)*rotz(pi/3)*scale(6, 4)*Arc()
# create_geometry(Arc())
# create_geometry(get_intersect_point_of_two_arcs(arc1, arc2)*Arc())

arct = trans(200, 100)*rotz(pi/6)*scale(200, 100)*Arc(1.5*pi)
# arct.scale_center(2)
# create_geometry(scale(2)*arct)
create_geometry(scale_point(arct.pointCenter, 2, 2)*arct)


# ----------------------------------------------------------------------------
# rela=get_intersect_line_of_two_planes(g_matrixE, trans(0,0,100)*roty(pi/6))
# rela=get_intersect_line_of_two_planes(g_matrixE, trans(0,0,50)*roty(pi/6))
# show_coordinate_plane(trans(0,0,50)*roty(pi/6))
# show_points_line(rela)


sec1 = Section([Vec2(0, -100), scale(150, 100)*Arc(pi)])
sec2 = trans(0, 0, 50)*roty(pi/6)*sec1
# sec2=trans(0,0,50)*roty(pi/6)*Section(Vec2(),Vec2(200,0),Vec2(0,100))
create_geometry(sec1)
create_geometry(sec2)
mat = get_orthogonal_matrix(sec2.transformation)*rotz(pi/4)
# show_coordinate_system(mat)

bl = is_two_sections_intersect(sec1, sec2)
spline = SplineCurve([Vec3(0, 0), Vec3(10, 10, 1), Vec3(20, 1), ])
bl = is_line_in_two_dimensional(spline)


# 点线距离
p = Vec3(5, 1, 0)
line = Segment(Vec3(2, 0, 0), Vec3(2, 2, 0))
d = get_distance_of_point_line(p, line)
d = get_distance_of_point_line(Vec2(0, 100), Segment(Vec3(), Vec3(100, 100)))
d = get_distance_of_point_line(Vec3(0, 100), Segment(Vec2(), Vec2(100, 100)))
print_result(is_float_equal(d, 100/sqrt(2)))

theta = get_angle_of_two_segments(
    [Vec2(), Vec2(100, 100)], [Vec2(), Vec2(100, 0)])
print_result(is_float_equal(theta, -pi/4))


is_two_segments_intersect_2D(Segment(Vec3(0, 0), Vec3(20, 20)), Segment(
                             Vec3(10, 0), Vec3(20, 10)))
is_two_segments_intersect_2D(
    Segment(Vec3(0, -10), Vec3(300, 100)), Segment(Vec3(200, 0), Vec3(100, 200)))

ln1 = Segment(Vec3(0, 0), Vec3(300, 100))
ln2 = Segment(Vec3(200, 0), Vec3(100, 200))
poi = get_intersect_point_of_two_lines(ln1, ln2)[0]
# poii=get_intersect(ln1, ln2)[0]
# show_points_line([poi],10)
# create_geometry(show_points_line([poi[0],ln2[1]],10))
# create_geometry(shear_x(1)*scale(100)*Cube())

p1 = Segment(Vec3(0, 0), Vec3(60098.1, 29586.95), )
p2 = Segment(Vec3(60098.1, 29586.95), Vec3(-213.5, 57773.33), )

res = is_two_line_intersect(p1, p2)
print_result(res == 'INTERSECT_V')


plane1 = trans(200, 0)*roty(-pi/6)
plane2 = trans(500, 0)*roty(-pi/6)
leng = get_distance_of_two_planes(trans(), trans(10, 20, 30))
leng = get_distance_of_two_planes(plane1, plane2)
enum = is_line_locate_on_plane(Segment(Vec2(), Vec2()), rotz())
test_arc = rotx(pi/3)*trans(100, 0)*scale(200, 100)*Arc()
# create_geometry(test_arc)
# show_arcs_and_axis(test_arc)
# show_points_line(get_three_points_from_arc(test_arc))
enum = is_point_on_arc(Vec2(sqrt(2), sqrt(2)), test_arc)
T = roty(pi/2)  # *rotx(pi/4)
# show_coordinate_system(T)
# show_coordinate_plane(T)
# show_coordinate_plane(test_arc.transformation)
p = get_intersect_point_of_arc_plane(test_arc, T)
